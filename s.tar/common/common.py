"""
Contains common functions to interact with the GC api
"""

import sys
import logging
import calendar

from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from ipaddress import IPv4Network, AddressValueError

from api.guardicore import RESTManagementAPI, ManagementAPIError

DEFAULT_LOGGER_FORMAT = "%(asctime)s:%(levelname)s: %(message)s"
DEFAULT_LOGGING_LEVEL = logging.INFO


def validate_python_version(minimum_major_version: int = 3, minimum_minor_version: int = 6):
    """Validate minimum python version requirements are met"""
    ver_info = sys.version_info
    try:
        assert ver_info.major >= minimum_major_version
        assert ver_info.minor >= minimum_minor_version
    except (AssertionError, Exception):
        logger.error(f"Incompatible python version detect. The script is intended to run using python version"
                     f" {minimum_major_version}.{minimum_minor_version} or newer")
        logger.info("If you run the script from a machine that has both python 2 and python 3, running the script with "
                    "python3 instead of python might solve this issue")


@contextmanager
def get_gc_api(management_address: str, auth_username: str, auth_password: str, management_port: int = 443,
               allow_2fa_auth=True):
    """
    A contextmanager that yields a Centra API connection object (RESTManagementAPI).
    An attempt to log out from Centra API will be preformed when the object is API connection is
    no longer needed (when leaving context).
    :raises AssertionError: if the provided management address contains 'https'
    """
    try:
        logger.debug(f"Connecting to Centra API at '{management_address}' over port {management_port}, using the "
                     f"username {auth_username}")
        if "https" in management_address:
            raise AssertionError(f"The provided management address {management_address} contains 'https', which should "
                                 f"not be provided. Please provide only the ip (i.e. 172.16.100.1) or fqdn "
                                 f"(i.e centra.example.com) of the management server, without https:// or any trailing "
                                 f"slashes")
        gc_api = RESTManagementAPI(management_host=management_address, allow_2fa_auth=allow_2fa_auth,
                                   username=auth_username, password=auth_password,
                                   port=management_port)
        yield gc_api
    finally:
        try:
            logger.debug(f"Trying to logout properly from Centra API")
            gc_api.logout()
        except NameError:
            pass
        except ManagementAPIError as error:
            logger.debug(f"Could not logout properly from Centra API. {repr(error)}")


def initiate_logger(logger_name: str = None, verbose: bool = False, log_file_path: str = "") -> logging.Logger:
    """
    Initiate a logger
    :param logger_name: The loggers name
    :param verbose: Whether to log debug information
    :param log_file_path: If specified, log also to a file in log_file_path. If log_file_path contains '*' sign,
    replace it with the current time
    :return: A logger object
    """
    script_logger = logging.getLogger(logger_name)
    formatter = logging.Formatter(DEFAULT_LOGGER_FORMAT)
    if verbose:
        log_level = logging.DEBUG
    else:
        log_level = DEFAULT_LOGGING_LEVEL
    logging.basicConfig(format=DEFAULT_LOGGER_FORMAT, level=log_level)
    if log_file_path:
        log_file_path = log_file_path.replace("*", datetime.now().strftime("%Y-%m-%d-%H.%M.%S"))
        fh = logging.FileHandler(Path(log_file_path))
        fh.setLevel(log_level)
        fh.setFormatter(formatter)
        script_logger.addHandler(fh)
    return script_logger


def datetime_to_timestamp(dt: datetime) -> int:
    """
    Convert a datetime object to timestamp in ms since epoch (which is the format used on Centra API).
    :param dt: datetime timestamp
    :return: dt as milliseconds since epoch
    """
    return int(calendar.timegm(dt.timetuple()) * 1000 + dt.microsecond / 1000)


def is_valid_connection_type(s: str) -> bool:
    """Return True if the input is one of the valid centra connection filters, or False else"""
    if not isinstance(s, str):
        return False
    return s.lower() in {"blocked", "associated with incident", "violated segmentation policy", "failed",
                         "redirected to deception", "established"}


def is_valid_policy_action(s: str) -> bool:
    """Return True if the input is one of the valid policy action filters, or False else"""
    if not isinstance(s, str):
        return False
    return s.lower() in {"allowed by policy", "alerted by policy", "blocked by policy", "no matching policy"}


def is_valid_internet_connection_type(s: str) -> bool:
    """Return True if the input is one of the valid internet connection types filters, or False else"""
    if not isinstance(s, str):
        return False
    return s.lower() in {"from internet", "to internet"}


def is_valid_ip_or_subnet(s: str) -> bool:
    """Return True if the input is a valid ipv4 address or subnet as a string, or False else"""
    if not isinstance(s, str):
        return False
    try:
        IPv4Network(str(s), strict=False)
        return True
    except AddressValueError:
        return False


def is_valid_port(i: int) -> bool:
    """Return True if the input is a valid individual port, or False else"""
    if not isinstance(i, int):
        return False
    return 1 <= i <= 65535


def is_valid_protocol(s: str) -> bool:
    """Return True if the input is one of the valid protocols filters, or False else"""
    if not isinstance(s, str):
        return False
    return s.upper() in {"TCP", "UDP"}


def remove_empty_values(data):
    """Remove None, empty lists and empty string values from lists, tuples, sets and dicts recursively"""
    if isinstance(data, (list, tuple, set)):
        return type(data)(remove_empty_values(x) for x in data if x not in (None, [], "", [None]))
    elif isinstance(data, dict):
        return type(data)((remove_empty_values(k), remove_empty_values(v)) for k, v in data.items()
                          if v not in (None, [], "", [None]))
    else:
        return data


logger = logging.getLogger()

