"""
    gc_labeler.py - Labeling tool for Guardicore Centra
    Version: 2.0.6
    Release date: 06/07/2020
"""

import sys
import csv
import re
import datetime
import logging
import string

from netaddr import IPNetwork, IPSet
from argparse import ArgumentParser
from collections import defaultdict
from getpass import getpass
from time import sleep
from typing import Dict, List, Tuple, Any, Set
from contextlib import contextmanager
from pathlib import Path

from api.guardicore import RESTManagementAPI, ManagementAPIError, ManagementAPITimeoutError
from common.labels.utils import Label, NameCriterion, StringIsNotNameCriterion, CHARS_ILLEGAL_IN_LABELS
from common.common import validate_python_version, initiate_logger

try:
    from configparser import NoOptionError, NoSectionError, ConfigParser, MissingSectionHeaderError
except ImportError:
    # Probably no python 3 installed. Will catch it during validate_python_version and exit
    pass

__author__ = 'yonatang'

validate_python_version()

# <editor-fold desc="---Constants---">
# Configuration file
CONF_PATH = "gc_labeler.ini"
# Export command headers
EXPORT_COMMAND_INFORMATIONAL_HEADERS = ["Comments", "Asset Status", "IP Addresses", "Asset ID"]
# GC API Settings
ASSET_OBJECTS_TO_GET_AT_ONCE = 1000
LABEL_OBJECTS_TO_GET_AT_ONCE = 1000
LABEL_OBJECTS_TO_GET_AT_ONCE_AFTER_TIMEOUT = 50
DYNAMIC_CRITERIA_LIMIT = 500000
# IP address with / without CIDR regex
IP_REGEX = r"^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])" \
           r"(/([0-9]|[1-2][0-9]|3[0-2]))?$"
# Subnets reserved for special usage, alert the user on the attempt to upload those as dynamic criteria
RESERVED_SUBNETS = IPSet(['224.0.0.0/3', "127.0.0.0/8", "0.0.0.0/8"])

DYNAMIC_TAG = ' <assigned dynamically>'

# Increase csv max field size to handle large label comments + for restore command
DEFAULT_CSV_FIELD_SIZE = csv.field_size_limit()
csv.field_size_limit(DEFAULT_CSV_FIELD_SIZE*1000)

# </editor-fold>


@contextmanager
def initiate_gc_api():
    """
    A contextmanager that yields a Centra API connection object (RESTManagementAPI) using credentials provided via
    command line or via an ini file. An attempt to log out from Centra API will be preformed when the object is API
    connection is no longer needed.
    """
    # If Centra credentials were passed as arguments, prompt for password
    if args.management_address and args.management_username:
        management_address = args.management_address
        management_username = args.management_username
        management_port = args.management_port
        management_password = getpass(f"Please provide the password for the user {management_username}: ")
    else:
        # Get configuration from ini file
        logger.info(f"Reading centra environment details from the ini file '{Path(args.ini_file_path)}'")
        try:
            config = ConfigParser(interpolation=None)
            with Path(args.ini_file_path).open("r") as conf_file:
                config.read_file(conf_file)
                try:
                    management_address = config.get("gc_api", "management_address")
                    management_username = config.get("gc_api", "username")
                    management_password = config.get("gc_api", "password")
                    management_port = config.get("gc_api", "port")
                except (NoSectionError, NoOptionError, MissingSectionHeaderError) as error:
                    logger.error(f"Error while reading the configuration file: {repr(error)}")
                    logger.info("Aborting..")
                    sys.exit(1)
        except IOError as error:
            logger.error(f"Error while reading the ini file: {repr(error)}")
            logger.info(f"Make sure you copied gc_labeler-sample.ini file to '{Path(args.ini_file_path)}'")
            logger.info("Aborting..")
            sys.exit(1)

    try:
        if "https" in management_address:
            logger.error(f"The provided management address {management_address} contains 'https', which should "
                         f"not be provided in this field. Please provide only the ip (i.e. 172.16.100.1) or fqdn "
                         f"(i.e centra.example.com) of the management server, without https:// or any trailing slashes")
            sys.exit(1)
        logger.info(f"Connecting to Centra API at '{management_address}' over port {management_port}, using the "
                    f"username {management_username}")
        gc_api = RESTManagementAPI(management_host=management_address, allow_2fa_auth=True,
                                   username=management_username, password=management_password,
                                   port=management_port)
        yield gc_api
    except ManagementAPIError as error:
        logger.error(f"Could not connect to Centra API: {repr(error)}")
        logger.info("Aborting..")
        sys.exit(1)
    finally:
        try:
            logger.debug(f"Trying to logout properly from Centra API")
            gc_api.logout()
        except NameError:
            pass
        except Exception as error:
            logger.debug(f"Could not Trying to logout properly from Centra API. {repr(error)}")


def get_centra_labels(gc_api: RESTManagementAPI, filter_keys: List[str] = None,
                      label_objects_to_get_at_once: int = LABEL_OBJECTS_TO_GET_AT_ONCE) -> List[Dict[str, Any]]:
    """
    Query Centra API for all the labels in Centra
    :param label_objects_to_get_at_once: The amount of label objects to request from the API in one call
    :param filter_keys: A list of keys. If provided, request only for labels with one of the provided keys
    :param gc_api: RESTManagementAPI object
    :return: a list containing all Centra label objects
    """
    logging.info("Fetching labels data from Centra")
    centra_labels = list()
    offset = 0
    logger.debug(f"Requesting for chunk of {label_objects_to_get_at_once} labels from Centra")
    try:
        if filter_keys:
            logger.debug(f"Requesting only labels with the following filter_keys: {filter_keys}")
            response = gc_api.list_visibility_labels(limit=label_objects_to_get_at_once,
                                                     dynamic_criteria_limit=DYNAMIC_CRITERIA_LIMIT,
                                                     key=','.join(filter_keys))
        else:
            response = gc_api.list_visibility_labels(limit=label_objects_to_get_at_once,
                                                     dynamic_criteria_limit=DYNAMIC_CRITERIA_LIMIT)
    except ManagementAPITimeoutError:
        logger.warning("The request for labels from Centra has timed out")
        logger.info("Sleeping for 60 seconds and trying again with a lower the number of labels requested at once.")
        label_objects_to_get_at_once = LABEL_OBJECTS_TO_GET_AT_ONCE_AFTER_TIMEOUT
        sleep(60)
        if filter_keys:
            logger.debug(f"Requesting only labels with the following filter_keys: {filter_keys}")
            response = gc_api.list_visibility_labels(limit=label_objects_to_get_at_once,
                                                     dynamic_criteria_limit=DYNAMIC_CRITERIA_LIMIT, key=filter_keys)
        else:
            response = gc_api.list_visibility_labels(limit=label_objects_to_get_at_once,
                                                     dynamic_criteria_limit=DYNAMIC_CRITERIA_LIMIT)
    while len(response["objects"]) > 0:
        for label_obj in response["objects"]:
            try:
                validate_label(label_obj)
                centra_labels.append(label_obj)
            except AssertionError as e:
                logger.warning(f"Invalid label found in Centra: {e}. Please contact Guardicore support")
                logger.debug(label_obj)
        if len(response["objects"]) == label_objects_to_get_at_once:
            offset += LABEL_OBJECTS_TO_GET_AT_ONCE
            logger.debug(f"Requesting {label_objects_to_get_at_once} labels from Centra, with offset {offset}")
            if filter_keys:
                response = gc_api.list_visibility_labels(limit=label_objects_to_get_at_once, offset=offset,
                                                         dynamic_criteria_limit=DYNAMIC_CRITERIA_LIMIT,
                                                         key=','.join(filter_keys))
            else:
                response = gc_api.list_visibility_labels(limit=label_objects_to_get_at_once, offset=offset,
                                                         dynamic_criteria_limit=DYNAMIC_CRITERIA_LIMIT)
        else:
            break
    logger.debug(f"Got {len(centra_labels)} labels from Centra")
    return centra_labels


def validate_label(label):
    """
    Validate a label object from Centra - check that its key and value are not empty, and that they does not contain
    illegal characters. If one of the checks failed, raise an Assertion error
    :param label: Label object from Centra
    :return: None
    """
    assert label.get("key"), f"The key of the label with label id '{label['id']}' is empty or None."
    illegal_characters_in_key = [char for char in CHARS_ILLEGAL_IN_LABELS if char in label["key"]]
    assert not illegal_characters_in_key, (f"The key of the label with label id '{label['id']}' contains "
                                           f"the character(s) '{', '.join(illegal_characters_in_key)}' "
                                           f"which are illegal for use in labels.")

    assert label.get("value"), f"The value of the label with label id '{label['id']}' is empty or None."
    illegal_characters_in_value = [char for char in CHARS_ILLEGAL_IN_LABELS if char in label["value"]]
    if not is_orchestration_label(label["key"]):
        assert not illegal_characters_in_value, (f"The value of the label with label id '{label['id']}' contains "
                                                 f"the character(s) '{', '.join(illegal_characters_in_value)} "
                                                 f"which are illegal for use in labels.")


def is_orchestration_label(key):
    """
    Return True if the label was automatically generated by Centra orchestration else, return False.
    Supported orchestrations are VMWare, AWS and Openshift / K8s

    """
    # vSphere orchestration keys
    if key in {'vCenter folder', 'vCenter host'}:
        return True
    # AWS orchestration keys
    if key in {'AWS Image ID', 'AWS Instance Type', 'AWS Owner ID', 'AWS Availability Zone'}:
        return True
    # K8s orchestration keys
    if key in {'OpenShift Namespace', 'Openshift Service', 'Openshift-io/component', 'Kubernetes-io/hostname',
               'OpenShift Node', 'OpenShift', 'Component', 'Beta-kubernetes-io/arch', 'Pod-template-generation',
               'Node-role-kubernetes-io/infra', 'Provider', 'Openshift-io/control-plane',
               'Node-role-kubernetes-io/master', 'Docker-registry', 'Controller-revision-hash', 'Router'}:
        return True
    # Azure orchestration keys
    if key in {'Azure Resource Group', 'Azure Location'}:
        return True
    return False


def print_all_actions(actions: List[str]) -> None:
    """Print all the actions to be taken by the script"""
    actions_separated_into_lines = "\n".join(actions)
    logger.info(f"All actions to be taken: \n{actions_separated_into_lines}")


def print_first_ten_actions(actions: List[str]) -> None:
    """Print the 10 first actions to be taken by the script (Or less if less actions will be taken)"""
    actions_separated_into_lines = "\n".join(actions[:10])
    if len(actions) > 10:
        logger.info(f"Sample of the actions to be taken: \n{actions_separated_into_lines}\n...")
        logger.info("To get a detailed list of all the actions to be taken, run the script with the verbose flag")
    else:
        logger.info(f"Actions to be taken: \n{actions_separated_into_lines}")


def print_action_summary_and_ask_for_confirmation(actions_as_strings: List[str]) -> bool:
    if args.verbose:
        print_all_actions(actions_as_strings)
    else:
        print_first_ten_actions(actions_as_strings)
    logger.info("------------------------------------------------------")

    if prompt_user_for_action_approval():
        logger.info("Actions were APPROVED")
        return True
    else:
        logger.info("Actions were NOT approved")
        logger.info("Aborting..")
        return False


def get_centra_assets(gc_api: RESTManagementAPI, include_deleted_assets: bool) -> List[Dict[str, Any]]:
    """
    Query Centra API for all the assets in Centra
    :param include_deleted_assets: Boolean, Whether to fetch also deleted assets from Centra
    :param gc_api: RESTManagementAPI object
    :return: a list containing all Centra asset objects
    """
    logging.info("Fetching assets' data from Centra")
    if include_deleted_assets:
        status = ["on", "off", "deleted"]
    else:
        status = ["on", "off"]
    centra_assets = list()
    offset = 0
    logger.debug(f"Requesting for chunk of {ASSET_OBJECTS_TO_GET_AT_ONCE} assets from Centra")
    response = gc_api.list_assets(limit=ASSET_OBJECTS_TO_GET_AT_ONCE, status=','.join(status))
    logger.debug(f"Received {len(response)} assets from Centra")
    while len(response) > 0:
        for asset in response:
            try:
                validate_asset(asset)
                centra_assets.append(asset)
            except AssertionError as e:
                logger.warning(f"Invalid asset found in Centra: {e}. Please contact Guardicore support")
                logger.debug(asset)
        if len(response) == ASSET_OBJECTS_TO_GET_AT_ONCE:
            offset += ASSET_OBJECTS_TO_GET_AT_ONCE
            logger.debug(f"Requesting for chunk of {ASSET_OBJECTS_TO_GET_AT_ONCE} assets from Centra with offset "
                         f"{offset}")
            response = gc_api.list_assets(limit=ASSET_OBJECTS_TO_GET_AT_ONCE, offset=offset, status=','.join(status))
            logger.debug(f"Received {len(response)} assets from Centra")
        else:
            break
    return centra_assets


def validate_asset(asset):
    """
    Validate a Centra asset object. Raise assertion error if the asset is missing name field.
    :param asset: a Centra asset object
    :return: None
    """
    assert "vm_name" in asset, "Asset missing vm_name field"
    assert asset["vm_name"], "Asset vm_name is empty or None"
    assert "name" in asset, "Asset missing name field"
    assert asset["name"], "Asset name is empty or None"


def is_subnet_or_ip(s):
    """
    Check if a string is a legal CIDR notated subnet or ip address.
    :return Boolean
    """
    return re.match(IP_REGEX, s)


def is_reserved_subnet(subnet):
    """
    Check if an IPNetwork is inside the RESERVED_SUBNETS
    :return Boolean
    """
    return subnet in RESERVED_SUBNETS


def prompt_user_for_action_approval():
    while True:
        logger.info("Please confirm performing the above actions")
        sleep(0.05)
        response = input("[y/n] ")
        if response.lower() in ("y", "yes"):
            return True
        elif response.lower() in ("n", "no"):
            return False
        else:
            logger.error("Invalid response.")


def string_to_filename(s):
    """Take a string and return a valid filename constructed from the string."""
    valid_chars = f"-_.() {string.ascii_letters}{string.digits}"
    filename = ''.join(c for c in s if c in valid_chars)
    filename = filename.replace(' ', '_')
    return filename


def parse_labels_csv(labels_file_path: str, ignore_labels_export_metadata: bool,
                     allow_duplicates: bool) -> Dict[str, List[Label]]:
    """
    Read labels to import or delete from a CSV file, and generate a dictionary mapping targets (assets / subnets / name 
    criteria) to their labels to import or delete.
    The first column in the CSV is the targets column. Can be Centra asset name, ip or a CIDR notated subnet, or 
    name criteria. The validation and parsing of the targets is not done in this function, but by other functions 
    later in the script's run.
    The first row of the CSV contains the label keys - the header of each column is a label key
    Every row after the first contains the target in the first column, and all the other columns contains a label's
    value. A label to import or delete is constructed from the columns header as key and the cell's content as a value.
    :param ignore_labels_export_metadata: Whether to automatically ignore metadata in the CSV created by the export
    command. If this flag is set to False and such metadata is found, the script will abort.
    :param allow_duplicates: Whether to allow specifying multiple values per key separated by comma
    :param labels_file_path: Path to the labels CSV file
    :return: a dictionary mapping every target to a list of it's labels to import or delete
    """
    logging.info(f"Reading labels from the CSV file '{labels_file_path}'")
    try:
        with open(labels_file_path, mode="r", encoding="utf8") as csv_file:
            reader = csv.DictReader(csv_file)
            # target_column - the first column in the CSV. Contains the asset names / subnets to add the labels to
            target_column = reader.fieldnames[0]

            # Perform validation on the label keys = the CSV column headers after the target_column header
            for column_number, key in enumerate(reader.fieldnames[1:], 2):
                illegal_characters_in_key = [char for char in CHARS_ILLEGAL_IN_LABELS if char in key]
                if illegal_characters_in_key:
                    logger.error(f"The header of column number {column_number} ('{key}') contains the characters "
                                 f"'{', '.join(illegal_characters_in_key)}' which are illegal for use in labels.")
                    logger.info("Aborting..")
                    sys.exit(1)
                if key in EXPORT_COMMAND_INFORMATIONAL_HEADERS:
                    if ignore_labels_export_metadata:
                        logger.debug(f"ignore_labels_export_metadata is True. Ignoring all the values of the "
                                     f"column header '{key}'.")
                    else:
                        logger.error(f"The header of column number {column_number} ('{key}') is generated by the "
                                     f"Export command. If you wish to ignore metadata generated by the export command, "
                                     f"re run the script with the --ignore_labels_export_metadata flag. \n"
                                     f"Refer to the section 'Using label export to backup the labels in Centra' in the "
                                     f"script's documentation for more info.")
                        logger.info("Aborting..")
                        sys.exit(0)

            raw_labels_for_targets = defaultdict(list)
            for row_number, row in enumerate(reader, 2):
                target = row.pop(target_column).strip()
                for key, values in row.items():  # values can be a single value or a comma separated multiple values
                    if not key:
                        logger.error(f"Row number {row_number} contains too many commas. Please fix the CSV and re "
                                     f"run the script.")
                        logger.info("Aborting..")
                        sys.exit(1)
                    if key in EXPORT_COMMAND_INFORMATIONAL_HEADERS:
                        continue
                    if values is None:
                        continue
                    if ',' in values:
                        # Multiple values were found in the cell
                        if allow_duplicates:
                            values = values.split(',')
                        else:
                            # Multiple values were found in the cell, but it is not allowed
                            logger.error(f"The value '{values}' for the key '{key}' in row {row_number} contains the "
                                         f"comma sign (',') which indicates multiple values, however the "
                                         f"--allow_duplicates flag was not provided. Please refer to the script's "
                                         f"documentation for more info")
                            logger.info("Aborting..")
                            sys.exit(1)
                    else:
                        # A single value in the cell
                        values = [values]
                    for value in values:
                        if value:
                            if DYNAMIC_TAG in value:
                                if ignore_labels_export_metadata:
                                    continue  # Ignore cells containing the dynamic criteria mark
                                else:
                                    logger.warning(f"The value '{value}' for the key '{key}' in row {row_number} "
                                                   f"contains the dynamic tag '{DYNAMIC_TAG}' which is generated by "
                                                   f"the Export command. If you wish to ignore those values, re run "
                                                   f"the script with the --ignore_labels_export_metadata flag. "
                                                   f"Refer to the section 'Using label export to backup the labels in "
                                                   f"Centra' in the script's documentation for more info")
                                    logger.info("Aborting..")
                                    sys.exit(0)
                            illegal_characters_in_value = [char for char in CHARS_ILLEGAL_IN_LABELS if char in value]
                            if illegal_characters_in_value:
                                logger.error(f"The value '{value}' for the key '{key}' in row {row_number} contains "
                                             f"the characters '{', '.join(illegal_characters_in_value)}' which are "
                                             f"illegal for use in labels.")
                                logger.info("Aborting..")
                                sys.exit(1)
                            raw_labels_for_targets[target].append(Label(key=key.strip(), value=value.strip()))
    except IOError as e:
        logger.error(f"Error while reading csv file '{labels_file_path}'. {repr(e)}.")
        logger.info("Aborting..")
        sys.exit(1)
    if raw_labels_for_targets:
        return raw_labels_for_targets
    else:
        logger.info("The CSV does not contain any labels to import or delete. Exiting..")
        sys.exit(0)


def sort_labels_for_targets_by_target_types(raw_labels_for_targets: Dict[str, List[Label]],
                                            ignore_name_criteria: bool) -> \
        Tuple[Dict[str, List[Label]], Dict[IPNetwork, List[Label]], Dict[NameCriterion, List[Label]]]:
    """
    Iterate over raw_labels_for_targets and sort the targets into subnets (match IPv4 ip / subnet), name_criteria, and
    potential Centra assets (The validation whether an asset indeed exists in Centra will be performed later).
    :param ignore_name_criteria: Bool. Whether to treat targets that includes '*' signs as name dynamic criteria or
    as normal asset names
    :param raw_labels_for_targets: a dictionary mapping every target to a list of it's labels to import or delete
    :return:
        labels_for_asset_targets: a dictionary mapping assets to their labels to import or delete
        labels_for_subnet_targets: a dictionary mapping IPNetwork objects to their labels to import
        labels_for_name_criteria_targets: a dictionary mapping name criteria to their labels to import
    """
    labels_for_asset_targets = dict()
    labels_for_subnet_targets = dict()
    labels_for_name_criteria_targets = dict()
    for row_number, (target, labels_to_import_for_target) in enumerate(raw_labels_for_targets.items(), 2):
        if is_subnet_or_ip(target):
            subnet = IPNetwork(target)
            if is_reserved_subnet(subnet):
                logger.warning(f"The subnet {subnet} mentioned in line {row_number} of the CSV is reserved for special"
                               f" uses.")
            labels_for_subnet_targets[subnet] = labels_to_import_for_target
        elif not ignore_name_criteria:
            try:
                name_criterion = NameCriterion.convert_string_to_name_dynamic_criteria_object(target)
                labels_for_name_criteria_targets[name_criterion] = labels_to_import_for_target
            except StringIsNotNameCriterion:
                asset_name = target.lower()  # Asset names are case insensitive
                labels_for_asset_targets[asset_name] = labels_to_import_for_target
        else:
            asset_name = target.lower()  # Asset names are case insensitive
            labels_for_asset_targets[asset_name] = labels_to_import_for_target
    return labels_for_asset_targets, labels_for_subnet_targets, labels_for_name_criteria_targets


def create_asset_name_to_asset_ids_mapping(centra_assets: Dict[str, Dict[str, Any]],
                                           relevant_assets: Set[str]) -> Dict[str, List[str]]:
    """
    Create a dictionary mapping asset names to all their asset ids. This is required because there might be
    multiple asset with the same name, and thus more than one asset_id for this asset_name.
    The script will warn the user in there are more than one asset with the same name, as it means both assets will be
    affected by the script's action in the same way (might or might not be the desired scenario)
    :param centra_assets: dictionary containing all centra assets (asset_id: asset_obj)
    :param relevant_assets: a set containing all the asset name targets from the CSV.
    :return: a dictionary mapping asset name to a list containing all it's asset_ids
    """
    asset_name_to_asset_ids = defaultdict(list)
    for asset_id, asset in centra_assets.items():
        asset_name = asset["vm_name"].lower()
        if asset_name not in relevant_assets:
            continue
        if asset_name in asset_name_to_asset_ids:
            logger.warning(f"Centra contains more than one asset with the name {asset['vm_name']}. "
                           f"Both assets will be labeled by the script")
        asset_name_to_asset_ids[asset_name].append(asset_id)
    return asset_name_to_asset_ids


def map_assets_to_explicit_labels(centra_labels: Dict[Label, Dict[str, Any]],
                                  asset_name_to_asset_ids: Dict[str, List[str]]) -> Dict[str, List[Label]]:
    """
    Map assets (by their asset_ids) to the a list of the labels they are currently explicitly labeled with in Centra.
    :param centra_labels: Dictionary containing all Centra labels
    :param asset_name_to_asset_ids: a dictionary mapping Centra asset_name to a list containing all it's asset_ids
    :return: A dictionary mapping every asset_id to a list of all it's current labels in Centra
    """
    all_asset_ids = set()
    for asset_ids in asset_name_to_asset_ids.values():
        for asset_id in asset_ids:
            all_asset_ids.add(asset_id)

    current_labels_for_assets = defaultdict(list)
    for label, label_obj in centra_labels.items():
        # Locate current labels for assets
        for criterion in label_obj["equal_criteria"]:
            if criterion['argument'] in all_asset_ids:
                asset_id = criterion['argument']
                current_labels_for_assets[asset_id].append(label)
    return current_labels_for_assets


def map_current_labels_for_subnets_as_strings(centra_labels: Dict[Label, Dict[str, Any]],
                                              relevant_subnets: Set[IPNetwork]) -> Dict[IPNetwork, List[Label]]:
    """
    Locate the current labels in Centra for each subnets that has labels to import or delete. Subnets are treated as
    strings - only subnets that match current criteria exactly will be counted. For example, the subnet 10.0.0.0/24
    will be considered inside the label App: Billing only if this label currently has 10.0.0.0/24 in its dynamic
    criteria, but not if it has 10.0.0.0/8.
    :param centra_labels: dict containing all Centra labels (Label: label_obj)
    :param relevant_subnets: a set containing all the subnets to map the current labels for.
    :return: A dictionary mapping every subnet to a list of all it's current labels in Centra
    """
    current_labels_for_subnets = defaultdict(list)
    for label, label_object in centra_labels.items():
        # Locate current labels for subnets and ip targets by iterating over the dynamic subnet criteria of the label
        for criterion in label_object["dynamic_criteria"]:
            if criterion['op'] == 'SUBNET':
                subnet = IPNetwork(criterion['argument'])
                if subnet in relevant_subnets:
                    current_labels_for_subnets[subnet].append(label)
    return current_labels_for_subnets


def map_current_labels_for_subnets_as_networks(centra_labels: Dict[Label, Dict[str, Any]],
                                               relevant_subnets: Set[IPNetwork]) -> Dict[IPNetwork, List[Label]]:
    """
    Locate the current labels in Centra for each subnets that has labels to import or delete. Subnets are treated as
    subnet objects. For example, the subnet 10.0.0.0/24 will be considered inside the label App: Billing if this label
    currently has 10.0.0.0/24 in its dynamic criteria, but also if it has the criteria 10.0.0.0/8.
    :param centra_labels: dict containing all Centra labels (Label: label_obj)
    :param relevant_subnets: a set containing all the subnets to map the current labels for.
    :return: A dictionary mapping every subnet to a list of all it's current labels in Centra
    """
    current_labels_for_subnets = defaultdict(list)
    for label, label_object in centra_labels.items():
        label_summarized_dynamic_subnet_criteria = \
            IPSet([criterion['argument'] for criterion in label_object["dynamic_criteria"]
                   if criterion['op'] == 'SUBNET'])
        # Check if subnet and ip targets are currently in this label by checking if they are included in the summarized
        # subnet dynamic criteria of the label
        for subnet in relevant_subnets:
            if subnet in label_summarized_dynamic_subnet_criteria:
                current_labels_for_subnets[subnet].append(label)
    return current_labels_for_subnets


def map_current_labels_for_name_criteria(centra_labels: Dict[Label, Dict[str, Any]],
                                         relevant_name_criteria: Set[NameCriterion]) -> \
        Dict[NameCriterion, List[Label]]:
    """
    Locate the current labels in Centra for each NameCriterion that has labels to import or delete.
    :param centra_labels: dict containing all Centra labels (Label: label_obj)
    :param relevant_name_criteria: a set containing all the NameCriterion to map the current labels for.
    :return: A dictionary mapping every NameCriterion to a list of all it's current labels in Centra
    """
    current_labels_for_name_criteria = defaultdict(list)
    for label, label_object in centra_labels.items():
        # Locate current labels for subnets and ip targets by iterating over the dynamic subnet criteria of the label
        for criterion in label_object["dynamic_criteria"]:
            if criterion['field'] == 'name':
                name_criterion = NameCriterion(criterion['argument'], criterion['op'])
                if name_criterion in relevant_name_criteria:
                    current_labels_for_name_criteria[name_criterion].append(label)
    return current_labels_for_name_criteria


def remove_subnet_as_string_from_label_criteria(subnet: IPNetwork,
                                                label_to_remove_the_subnet_from: Dict[str, Any]) -> None:
    """
    Remove the subnet from the label's criteria. The subnet is treated as a string, meaning only the exact same subnet
    will be removed from the label's criteria. For example, if subnet == 10.0.0.1/32, the dynamic criteria 10.0.0.1/32
    will be removed from the label, but the dynamic criteria 10.0.0.0/24 will not be changed
    :param subnet: Subnet to remove from the label's criteria
    :param label_to_remove_the_subnet_from: The label to remove the subnet from
    """
    current_dynamic_criteria = label_to_remove_the_subnet_from["dynamic_criteria"]
    new_dynamic_criteria = \
        [criterion for criterion in current_dynamic_criteria if not
            (criterion["op"] == "SUBNET" and IPNetwork(criterion["argument"]) == subnet)]
    label_to_remove_the_subnet_from["dynamic_criteria"] = new_dynamic_criteria


def remove_subnet_as_network_from_label_criteria(subnet: IPNetwork,
                                                 label_to_remove_the_subnet_from: Dict[str, Any]) -> None:
    """
    Remove the subnet from the label's criteria. The subnet is treated as a network object, meaning it will be removed
    from all the label's criteria that it's included in. For example, if subnet == 10.0.0.0/28,
    the dynamic criteria 10.0.0.0/28 will be removed from the label completely, and the dynamic criteria 10.0.0.0/24
    will be updated to the for dynamic criteria '10.0.0.16/28', '10.0.0.32/27', '10.0.0.64/26', '10.0.0.128/25' that
    are equal to 10.0.0.0/24 excluding 10.0.0.0/28
    :param subnet: IPNetwork object. Subnet to remove from the label's criteria
    :param label_to_remove_the_subnet_from: Label object as it is returned from Centra API.
    :return:
    """
    subnet_as_ip_set = IPSet([subnet])
    new_label_dynamic_criteria = list()
    new_cidrs = set()
    for current_criterion in label_to_remove_the_subnet_from["dynamic_criteria"]:
        if current_criterion["op"] == "SUBNET" and subnet in IPNetwork(current_criterion["argument"]):
            current_criterion_as_ip_set = IPSet([current_criterion["argument"]])
            new_criteria = current_criterion_as_ip_set - subnet_as_ip_set
            new_cidrs.update(new_criteria.iter_cidrs())
            logger.debug(f"The subnet {str(subnet)} is contained in the current criteria "
                         f"{current_criterion['argument']} of the label {label_to_remove_the_subnet_from['key']}: "
                         f"{label_to_remove_the_subnet_from['value']}")
            logger.debug(f"Removing the subnet from the current criteria in the following subnets: "
                         f"{', '.join([str(cidr) for cidr in new_criteria.iter_cidrs()])}")
        else:
            new_label_dynamic_criteria.append(current_criterion)
    for cidr in new_cidrs:
        new_label_dynamic_criteria.append({"field": "numeric_ip_addresses", "op": "SUBNET", "argument": str(cidr)})
    label_to_remove_the_subnet_from["dynamic_criteria"] = new_label_dynamic_criteria


def update_centra_labels(gc_api: RESTManagementAPI, labels_with_updates: Set[Label],
                         centra_labels: Dict[Label, Dict[str, Any]]) -> None:
    """
    Send label update requests to Centra
    :param centra_labels: dict containing all Centra labels (Label: label_obj). Labels that should be updated were
    updated on this dict.
    :param labels_with_updates: a set of all the labels that have updates
    :param gc_api: RESTManagementAPI object
    """
    for label_to_update in labels_with_updates:
        label_obj = centra_labels[label_to_update]
        logger.debug(f"Updating the criteria of label '{label_to_update}' with label id {label_obj['_id']}")
        try:
            gc_api.update_visibility_label(label_obj)
        except ManagementAPIError as e:
            logger.error(f"Could not update the label '{label_to_update}' with label id {label_obj['_id']}. {repr(e)}")


def remove_assets_from_labels(gc_api: RESTManagementAPI, labels_to_remove_assets_from: Dict[Label, List[str]]) -> None:
    """
    Send asset removal requests from labels to Centra
    :param labels_to_remove_assets_from: dict containing a mapping of labels to a list of asset_ids to remove from them
    :param gc_api: RESTManagementAPI object
    """
    for label, asset_ids_to_remove in labels_to_remove_assets_from.items():
        logger.debug(f"Removing {len(asset_ids_to_remove)} asset(s) from the label '{label}'.")
        try:
            gc_api.remove_assets_from_label(asset_ids_to_remove, label.key, label.value)
        except ManagementAPIError as e:
            logger.error(f"Failed to remove the assets from the label '{label}'. {repr(e)}")


# <editor-fold desc="import command">
def import_labels_from_csv():
    """
    Import labels main function.
    """
    raw_labels_to_import = parse_labels_csv(args.labels_file_path, args.ignore_labels_export_metadata,
                                            args.allow_duplicates)
    raw_labels_to_import_for_assets, raw_labels_to_import_for_subnets, labels_to_import_for_name_criteria = \
        sort_labels_for_targets_by_target_types(raw_labels_to_import, args.ignore_name_criteria)

    with initiate_gc_api() as gc_api:
        centra_assets_raw = get_centra_assets(gc_api, include_deleted_assets=args.include_deleted_assets)
        centra_assets = {asset["id"]: asset for asset in centra_assets_raw}

        centra_labels_raw = get_centra_labels(gc_api)
        centra_labels = {Label(label_obj["key"], label_obj["value"]): label_obj for label_obj in centra_labels_raw if
                         not is_orchestration_label(label_obj['key'])}

        labels_to_import_for_assets, duplicate_labels_for_assets, assets_not_in_centra = \
            process_raw_labels_to_import_for_assets(raw_labels_to_import_for_assets, centra_labels, centra_assets)

        labels_to_import_for_subnets, duplicate_labels_for_subnets = \
            process_raw_labels_to_import_for_subnets(raw_labels_to_import_for_subnets, centra_labels,
                                                     args.treat_subnets_as_networks)

        labels_to_import_for_name_criteria, duplicate_labels_for_name_criteria = \
            process_raw_labels_to_import_for_name_criteria(labels_to_import_for_name_criteria, centra_labels)

        # A dictionary to store the new labels to create. Structure: {Label: criteria}
        centra_labels_to_create = defaultdict(dict)
        # A set to store all the labels that need to be modified
        centra_labels_to_update = set()
        # A list to store the actions to be taken as strings.
        actions_as_strings = list()

        labels_to_remove_assets_from = \
            generate_import_and_update_actions_for_assets(labels_to_import_for_assets, duplicate_labels_for_assets,
                                                          args.allow_duplicates, centra_labels, centra_assets,
                                                          centra_labels_to_create, centra_labels_to_update,
                                                          actions_as_strings)

        generate_import_and_update_actions_for_subnets(labels_to_import_for_subnets,
                                                       duplicate_labels_for_subnets, args.allow_duplicates,
                                                       centra_labels, centra_labels_to_create, centra_labels_to_update,
                                                       actions_as_strings, args.treat_subnets_as_networks)

        generate_import_and_update_actions_for_name_criteria(labels_to_import_for_name_criteria,
                                                             duplicate_labels_for_name_criteria,
                                                             args.allow_duplicates, centra_labels,
                                                             centra_labels_to_create, centra_labels_to_update,
                                                             actions_as_strings)

        env_name = gc_api.get_env_name()

        num_of_labels_with_updates = len(centra_labels_to_update | set(labels_to_remove_assets_from.keys()))
        if print_summary_and_ask_for_confirmation_for_import_action(len(centra_labels_to_create),
                                                                    num_of_labels_with_updates, actions_as_strings,
                                                                    assets_not_in_centra, env_name):
            if centra_labels_to_create:
                upload_new_labels_to_centra(gc_api, centra_labels_to_create)
            if centra_labels_to_update:
                update_centra_labels(gc_api, centra_labels_to_update, centra_labels)
            if labels_to_remove_assets_from:
                remove_assets_from_labels(gc_api, labels_to_remove_assets_from)

            logger.info(f"Finished importing labels to {env_name}.")


def process_raw_labels_to_import_for_assets(raw_labels_to_import_for_assets, centra_labels, centra_assets):
    """
    Process the raw labels to import for assets. For each asset:
    1. Validate whether it is indeed a legal asset in Centra (targets that are actually not assets will be detected
    in this function)
    2. Create a list of all the new labels that should be imported for it (= the asset is not currently explicitly
    labeled with them)
    3. Create a list of all the duplicate labels (multiple labels with the same key) it will have in case the labels
    import action will be performed.
    :param raw_labels_to_import_for_assets: a dictionary mapping every asset to the list of it's labels to import
    :param centra_labels: dict containing all Centra labels ((key, value): label_obj)
    :param centra_assets: dict containing all Centra assets (asset_id: asset_obj)
    :return:
        labels_to_import - dict mapping each asset_id to it's labels to import
        duplicate_labels - dict mapping each asset_id to it's duplicate labels
        assets_not_in_centra - list of assets that were mentioned in the CSV but were not found in Centra
    """
    # Locate assets that were mentioned in the CSV but are missing from Centra
    assets_not_in_centra = set()
    asset_name_to_asset_ids = create_asset_name_to_asset_ids_mapping(centra_assets,
                                                                     set(raw_labels_to_import_for_assets.keys()))
    for potential_asset in raw_labels_to_import_for_assets:
        if potential_asset not in asset_name_to_asset_ids:
            logger.warning(f"The asset {potential_asset} was not found in Centra.")
            assets_not_in_centra.add(potential_asset)
    # Remove non existing assets from raw_labels_to_import_for_assets
    for asset_not_in_centra in assets_not_in_centra:
        del raw_labels_to_import_for_assets[asset_not_in_centra]

    current_explicit_labels_for_assets = map_assets_to_explicit_labels(centra_labels, asset_name_to_asset_ids)
    labels_to_import = defaultdict(list)
    duplicate_labels = dict()
    for asset_name, raw_labels_to_import_for_asset in raw_labels_to_import_for_assets.items():
        # There might be more than one asset with the same name, so it is necessary to iterate over all those
        for asset_id in asset_name_to_asset_ids[asset_name]:
            current_labels_for_asset = current_explicit_labels_for_assets.get(asset_id, list())
            for label_to_import in raw_labels_to_import_for_asset:
                if label_to_import in current_labels_for_asset:
                    logger.debug(f"The asset {asset_name} with the asset_id '{asset_id}' is already labeled with "
                                 f"the label '{label_to_import}'")
                else:
                    labels_to_import[asset_id].append(label_to_import)

            duplicate_labels_for_asset = \
                locate_duplicate_labels_for_asset(asset_id, asset_name, raw_labels_to_import_for_asset,
                                                  current_labels_for_asset)
            if duplicate_labels_for_asset:
                duplicate_labels[asset_id] = duplicate_labels_for_asset

    return labels_to_import, duplicate_labels, assets_not_in_centra


def locate_duplicate_labels_for_asset(asset_id, asset_name, raw_labels_to_import_for_asset, current_labels_for_asset):
    """
    Locate all the labels that the asset is currently labeled with them that have the same key as one of the raw
    labels to import. Those labels, in case the labels import completes, will become "duplicate labels" for
    the asset - meaning the asset will have two labels with the same key and different values. This might not be
    desirable, and will be handled by the script unless the allow_duplicates flag was set.
    locate_duplicate_labels_for_assets runs on the raw_labels_to_import_for_target to allow removing duplicates even
    the case there is no need to actually upload any label for the asset
    :param asset_name: The asset name of the asset to import the labels for
    :param asset_id: the asset_id of the asset to import the labels for
    :param raw_labels_to_import_for_asset: a list of labels to import for the target asset, as extracted from the import
    CSV
    :param current_labels_for_asset: a list of labels that the asset is currently explicitly labeled with in Centra
    :return: a dict mapping each label to import of the asset to a list of the duplicate labels it has in Centra
    """
    duplicate_labels_of_asset = defaultdict(list)
    for label_to_import in raw_labels_to_import_for_asset:
        for current_label in current_labels_for_asset:
            if current_label.key == label_to_import.key and current_label.value != label_to_import.value:
                logger.debug(f"The asset {asset_name} with asset id '{asset_id}' already has a value for the "
                             f"key '{label_to_import.key}'. Current value: '{current_label.value}'. "
                             f"New value from the CSV: '{label_to_import.value}'.")
                duplicate_labels_of_asset[label_to_import].append(current_label)
    return duplicate_labels_of_asset


def process_raw_labels_to_import_for_subnets(raw_labels_to_import_for_subnets, centra_labels,
                                             treat_subnets_as_networks):
    """
    Process the raw labels to import for subnets. For each subnet:
    1. Create a list of all the new labels that should be imported for it (= the subnet is not already labeled in
     Centra with this label)
    2. Create a list of all the duplicate labels (multiple labels with the same key) it will have in case the labels
    import action will be performed.
    :param treat_subnets_as_networks: If True, subnets will be treated as network objects. This means that the
    subnet will be counted as if it is already labeled with some label if the label current criteria covers this subnet.
    For example - 10.0.0.1/32 will be counted inside the label App: Ecomm if the App: Ecomm has a dynamic subnet
    criteria of 10.0.0.0/8.
    If False, only exact matches will be counted - 10.0.0.1/32 not already covered by 10.0.0.0/8
    :param raw_labels_to_import_for_subnets: a dictionary mapping every subnet to the list of it's labels to import
    :param centra_labels: dict containing all Centra labels ((key, value): label_obj)
    :return:
        labels_to_import - dict mapping each subnet to it's labels to import
        duplicate_labels - dict mapping each subnet to it's duplicate labels
    """
    labels_to_import = defaultdict(list)
    duplicate_labels = dict()
    if treat_subnets_as_networks:
        current_labels_for_subnets = \
            map_current_labels_for_subnets_as_networks(centra_labels, set(raw_labels_to_import_for_subnets.keys()))
    else:
        current_labels_for_subnets = \
            map_current_labels_for_subnets_as_strings(centra_labels, set(raw_labels_to_import_for_subnets.keys()))

    for subnet, raw_labels_to_import_for_subnet in raw_labels_to_import_for_subnets.items():
        current_labels_for_subnet = current_labels_for_subnets.get(subnet, list())
        for label_to_import in raw_labels_to_import_for_subnet:
            if label_to_import in current_labels_for_subnet:
                logger.debug(f"The subnet {subnet} is already labeled with the label '{label_to_import.key}: "
                             f"{label_to_import.value}'")
            else:
                labels_to_import[subnet].append(label_to_import)

        duplicate_labels_for_subnet = \
            locate_duplicate_labels_for_subnet(subnet, raw_labels_to_import_for_subnet, current_labels_for_subnet)
        if duplicate_labels_for_subnet:
            duplicate_labels[subnet] = duplicate_labels_for_subnet

    return labels_to_import, duplicate_labels


def locate_duplicate_labels_for_subnet(subnet, raw_labels_to_import_for_subnet, current_labels_for_subnet):
    """
    Locate all the labels that the subnet / ip is currently labeled with them that have the same key as one of the raw
    labels to import. Those labels, in case the labels import completes, will become "duplicate labels" for
    the subnet - meaning the subnet has two labels with the same key and different values. This might not be desirable,
    and will be handled by the script unless the allow_duplicates flag was set.
    locate_duplicate_labels_for_subnet runs on the raw_labels_to_import_for_target to allow removing duplicates even
    the case there is no need to actually upload any label for the subnet
    :param subnet: the target subnet or ip to add import the labels for
    :param raw_labels_to_import_for_subnet: a list of labels to import for the target subnet, as extracted from the
    import CSV
    :param current_labels_for_subnet: a list of labels that the subnet / ip is currently labeled with in Centra
    :return: a dict mapping each new label of the subnet / ip to a list of the duplicate labels it has in Centra -
    {(key, new_value_from_csv): [(key, value_from_centra_a), (key, value_from_centra_b), ...]
    """
    duplicate_labels_of_subnet = defaultdict(list)
    for label_to_import in raw_labels_to_import_for_subnet:
        for current_label in current_labels_for_subnet:
            if current_label.key == label_to_import.key and current_label.value != label_to_import.value:
                logger.debug(f"The subnet '{subnet}' already has a value for the key '{label_to_import.key}'. "
                             f"Current value: '{current_label.value}'. New value from the CSV: "
                             f"'{label_to_import.value}'.")
                duplicate_labels_of_subnet[label_to_import].append(current_label)
    return duplicate_labels_of_subnet


def process_raw_labels_to_import_for_name_criteria(raw_labels_to_import_for_name_criteria, centra_labels):
    """
    Process the raw labels to import for name criteria. For each NameCriterion:
    1. Create a list of all the new labels that should be imported for it (= the name criteria is not already labeled in
     Centra with this label)
    2. Create a list of all the duplicate labels (multiple labels with the same key) it will have in case the labels
    import action will be performed.
    :param raw_labels_to_import_for_name_criteria: a dictionary mapping each NameCriterion to the list of it's
    labels to import
    :param centra_labels: dict containing all Centra labels ((key, value): label_obj)
    :return:
        labels_to_import - dict mapping each NameCriterion to it's labels to import
        duplicate_labels - dict mapping each NameCriterion to it's duplicate labels
    """
    labels_to_import = defaultdict(list)
    duplicate_labels = dict()
    current_labels_for_name_criteria = \
        map_current_labels_for_name_criteria(centra_labels, set(raw_labels_to_import_for_name_criteria.keys()))

    for name_criterion, raw_labels_to_import_for_name_criterion in raw_labels_to_import_for_name_criteria.items():
        current_labels_for_name_criterion = current_labels_for_name_criteria.get(name_criterion, list())
        for label_to_import in raw_labels_to_import_for_name_criterion:
            if label_to_import in current_labels_for_name_criterion:
                logger.debug(f"The name criterion {name_criterion} is already part of the criteria of the label "
                             f"'{label_to_import}'")
            else:
                labels_to_import[name_criterion].append(label_to_import)

        duplicate_labels_for_name_criterion = \
            locate_duplicate_labels_for_name_criterion(name_criterion, raw_labels_to_import_for_name_criterion,
                                                       current_labels_for_name_criterion)
        if duplicate_labels_for_name_criterion:
            duplicate_labels[name_criterion] = duplicate_labels_for_name_criterion

    return labels_to_import, duplicate_labels


def locate_duplicate_labels_for_name_criterion(name_criterion, raw_labels_to_import_for_name_criterion,
                                               current_labels_for_name_criterion):
    """
    Locate all the labels that the name criterion is currently labeled with them that have the same key as one of the
    raw labels to import. Those labels, in case the labels import is executed, will become "duplicate labels" for
    the name criterion - meaning the name criterion will have two labels with the same key and different values.
    This might not be desirable, and will be overridden by the script unless the allow_duplicates flag was set.
    locate_duplicate_labels_for_name_criterion runs on the raw_labels_to_import_for_target to allow removing
    duplicates even if there is no need to actually upload any label for the name criterion
    :param name_criterion: the target name_criterion to import the labels for
    :param raw_labels_to_import_for_name_criterion: a list of labels to import for the target name_criterion,
    as extracted from the import CSV
    :param current_labels_for_name_criterion: a list of labels that the name criterion is currently labeled with in
    Centra
    :return: a dict mapping each new label of the name criterion to a list of the duplicate labels it has in Centra -
    {(key, new_value_from_csv): [(key, value_from_centra_a), (key, value_from_centra_b), ...]}
    """
    duplicate_labels_of_name_criterion = defaultdict(list)
    for label_to_import in raw_labels_to_import_for_name_criterion:
        for current_label in current_labels_for_name_criterion:
            if current_label.key == label_to_import.key and current_label.value != label_to_import.value:
                logger.debug(f"The name criterion '{name_criterion}' already has a value for the key "
                             f"'{label_to_import.key}'. Current value: '{current_label.value}'. "
                             f"New value from the CSV: '{label_to_import.value}'.")
                duplicate_labels_of_name_criterion[label_to_import].append(current_label)
    return duplicate_labels_of_name_criterion


def generate_import_and_update_actions_for_assets(labels_to_import, duplicate_labels, allow_duplicates, centra_labels,
                                                  centra_assets, centra_labels_to_create, centra_labels_to_update,
                                                  actions_as_strings):
    """
    Process the labels to import and the duplicate labels for each asset:
     - Populate centra_labels_to_create with Centra labels that need to be created
     - Populate centra_labels_with_updates with Centra labels that need to be updated
     - Populate actions_as_strings with actions to be taken as string.
     - Populate labels_to_remove_assets_from with labels that should be removed from assets because they are duplicates.
    :param actions_as_strings: Empty list to store actions to be taken as string (i.e. "Importing the label
    'App: Ecomm' for the asset 'DC-10' with asset_id xxxx").
    :param centra_labels_to_update: empty set to store Labels pointing to the Centra labels that have updates
    (the actual updates are made on centra_labels dict)
    :param centra_labels_to_create: empty dictionary to map new Centra label to its criteria (asset_ids, subnets, ips)
    :param labels_to_import: a dict mapping each asset_id to a list of its labels to import
    :param duplicate_labels: a dict mapping each asset_id to a dict mapping each of its new labels to a list of
     the duplicate labels it has in Centra
    :param allow_duplicates: Boolean - Whether to allow duplicate labels or override them
    :param centra_labels: dict containing all Centra labels (Label: label_obj). Changes to labels that should be
    updated are performed on label objects in this dict
    :param centra_assets: dict containing all Centra assets (asset_id: asset_obj)
    :return: labels_to_remove_assets_from - mapping of labels to a list of asset_ids to remove from them
    """
    labels_to_remove_assets_from = defaultdict(list)

    for asset_id in labels_to_import:
        asset_name = centra_assets[asset_id]['vm_name'].lower()
        for label_to_import in labels_to_import[asset_id]:
            action = f"Importing the label '{label_to_import}' for the asset " \
                     f"{asset_name} with asset_id '{asset_id}'"
            # Import the label for the target by adding a criteria to an existing label or create a new label in case
            # the label does not exist in Centra yet
            if label_to_import in centra_labels:
                label_to_add_the_asset_to = centra_labels[label_to_import]
                centra_labels_to_update.add(label_to_import)
            else:
                label_to_add_the_asset_to = centra_labels_to_create[label_to_import]
            # "equal criteria" is the criterion for explicit labels
            if "equal_criteria" not in label_to_add_the_asset_to:
                label_to_add_the_asset_to["equal_criteria"] = list()
            label_to_add_the_asset_to["equal_criteria"].append({"field": "id", "op": "EQUALS", "argument": asset_id})

            # mark duplicate labels of labels that are going to be imported for deletion
            if not allow_duplicates and label_to_import in duplicate_labels.get(asset_id, dict()):
                duplicate_labels_string = ", ".join([f'{label}' for label in
                                                     duplicate_labels[asset_id][label_to_import]])
                action += f", overriding the current label(s): {duplicate_labels_string}"
                for duplicate_label in duplicate_labels[asset_id][label_to_import]:
                    labels_to_remove_assets_from[duplicate_label].append(asset_id)
                # remove the duplicate labels list so it wont be iterated over twice
                del duplicate_labels[asset_id][label_to_import]

            actions_as_strings.append(action)

    # Mark for removal duplicate labels of labels that are mentioned in the CSV for the asset but not going to be
    # imported because the asset is already labeled with them in Centra
    if not allow_duplicates:
        for asset_id in duplicate_labels:
            if not duplicate_labels[asset_id]:
                continue
            for label_that_already_exist, duplicate_labels_list in duplicate_labels[asset_id].items():
                asset_name = centra_assets[asset_id]['vm_name'].lower()
                duplicate_labels_string = ", ".join([f"'{label}'" for label in duplicate_labels_list])
                action = f"Overriding the label(s) {duplicate_labels_string} that are duplicates of the label " \
                         f"'{label_that_already_exist}', for the asset {asset_name} with asset_id '{asset_id}'"
                for duplicate_label in duplicate_labels_list:
                    labels_to_remove_assets_from[duplicate_label].append(asset_id)
                actions_as_strings.append(action)
    return labels_to_remove_assets_from


def generate_import_and_update_actions_for_subnets(labels_to_import, duplicate_labels, allow_duplicates,
                                                   centra_labels, centra_labels_to_create,
                                                   centra_labels_to_update, actions_as_strings,
                                                   treat_subnets_as_networks):
    """
    Process the labels to import and the duplicate labels for each subnet (subnets are treated as strings):
     - Populate centra_labels_to_create with Centra labels that need to be created
     - Populate centra_labels_with_updates with Centra labels that need to be updated
     - Populate actions_as_strings with actions to be taken as string.
    :param treat_subnets_as_networks: If True, subnets will be overridden from duplicate labels using
    remove_subnet_as_network_from_label_criteria, and if False with  remove_subnet_as_string_from_label_criteria
    :param actions_as_strings: list of actions to be taken as string  (i.e. "Importing the label 'App: Ecomm' for
    '10.0.0.30/32'").
    :param centra_labels_to_update: a set of Labels pointing to the Centra labels that have updates
    (the actual updates are made on centra_labels dict)
    :param centra_labels_to_create: dictionary mapping a new Centra label to its criteria (asset_ids, subnets, ips)
    :param labels_to_import: a dict mapping each subnet to a list of its labels to import
    :param duplicate_labels: a dict mapping each subnet to a dict mapping each of its new labels to a list of
     the duplicate labels it has in Centra
    :param allow_duplicates: Boolean - Whether to allow duplicate labels or override them
    :param centra_labels: dict containing all Centra labels (Label: label_obj). Changes to labels that should be
    updated are performed on label objects in this dict
    :return: None
    """

    for subnet in labels_to_import:
        for label_to_import in labels_to_import[subnet]:
            action = f"Importing the label '{label_to_import}' for the subnet {subnet}"
            # Import the label for the target by adding a criterion to an existing label or create a new label in case
            # the label does not exist in Centra yet
            if label_to_import in centra_labels:
                label_to_add_the_subnet_to = centra_labels[label_to_import]
                centra_labels_to_update.add(label_to_import)
            else:
                label_to_add_the_subnet_to = centra_labels_to_create[label_to_import]

            if "dynamic_criteria" not in label_to_add_the_subnet_to:
                label_to_add_the_subnet_to["dynamic_criteria"] = list()
            label_to_add_the_subnet_to["dynamic_criteria"].append({"field": "numeric_ip_addresses", "op": "SUBNET",
                                                                   "argument": str(subnet)})

            # Mark duplicate labels for deletion
            if not allow_duplicates and label_to_import in duplicate_labels.get(subnet, dict()):
                duplicate_labels_string = ", ".join([f"'{label}'" for label in
                                                     duplicate_labels[subnet][label_to_import]])
                action += f", overriding the current label(s): {duplicate_labels_string}"
                for duplicate_label in duplicate_labels[subnet][label_to_import]:
                    if treat_subnets_as_networks:
                        remove_subnet_as_network_from_label_criteria(subnet, centra_labels[duplicate_label])
                    else:
                        remove_subnet_as_string_from_label_criteria(subnet, centra_labels[duplicate_label])
                    centra_labels_to_update.add(duplicate_label)
                # remove the duplicate labels list so it wont be iterated over twice
                del duplicate_labels[subnet][label_to_import]

            actions_as_strings.append(action)

    # Mark for removal duplicate labels of labels that are mentioned in the CSV for the subnet but not going to be
    # imported because the subnet is already labeled with them in Centra
    if not allow_duplicates:
        for subnet in duplicate_labels:
            if not duplicate_labels[subnet]:
                continue
            for label_that_already_exist, duplicate_labels_list in duplicate_labels[subnet].items():
                duplicate_labels_string = ", ".join([f"'{label}'" for label in duplicate_labels_list])
                action = f"Overriding the label(s) {duplicate_labels_string} that are duplicates of the label " \
                         f"'{label_that_already_exist}', for the subnet {subnet}"
                for duplicate_label in duplicate_labels_list:
                    if treat_subnets_as_networks:
                        remove_subnet_as_network_from_label_criteria(subnet, centra_labels[duplicate_label])
                    else:
                        remove_subnet_as_string_from_label_criteria(subnet, centra_labels[duplicate_label])
                    centra_labels_to_update.add(duplicate_label)
                # remove the duplicate labels list so it wont be iterated over twice
                actions_as_strings.append(action)
    return


def generate_import_and_update_actions_for_name_criteria(labels_to_import, duplicate_labels, allow_duplicates,
                                                         centra_labels, centra_labels_to_create,
                                                         centra_labels_to_update, actions_as_strings):
    """
    Process the labels to import and the duplicate labels for each name criterion:
     - Populate centra_labels_to_create with Centra labels that need to be created
     - Populate centra_labels_with_updates with Centra labels that need to be updated
     - Populate actions_as_strings with actions to be taken as string.
    :param actions_as_strings: list of actions to be taken as string  (i.e. "Adding the criterion 'Asset name starts
    with 'Ecomm'' to the label 'App: Ecomm'").
    :param centra_labels_to_update: a set of Labels pointing to the Centra labels that have updates
    (the actual updates are made on centra_labels dict)
    :param centra_labels_to_create: dictionary mapping a new Centra label to its criteria (asset_ids, subnets,
    name criteria)
    :param labels_to_import: a dict mapping each name criterion to a list of its labels to import
    :param duplicate_labels: a dict mapping each name criterion to a dict mapping each of its new labels to a list of
     the duplicate labels it has in Centra
    :param allow_duplicates: Boolean - Whether to allow duplicate labels or override them
    :param centra_labels: dict containing all Centra labels (Label: label_obj). Changes to labels that should be
    updated are performed on label objects in this dict
    :return: None
    """

    for name_criterion in labels_to_import:
        for label_to_import in labels_to_import[name_criterion]:
            action = f"Adding the criterion \"{name_criterion}\" to the criteria of the label '{label_to_import}'"
            # Import the label for the target by adding a criterion to an existing label or create a new label in case
            # the label does not exist in Centra yet
            if label_to_import in centra_labels:
                label_to_add_the_name_criterion_to = centra_labels[label_to_import]
                centra_labels_to_update.add(label_to_import)
            else:
                label_to_add_the_name_criterion_to = centra_labels_to_create[label_to_import]

            if "dynamic_criteria" not in label_to_add_the_name_criterion_to:
                label_to_add_the_name_criterion_to["dynamic_criteria"] = list()
            label_to_add_the_name_criterion_to["dynamic_criteria"].append({"field": "name",
                                                                           "op": name_criterion.criterion_type,
                                                                           "argument": name_criterion.name})

            # Mark duplicate labels for deletion
            if not allow_duplicates and label_to_import in duplicate_labels.get(name_criterion, dict()):
                duplicate_labels_string = ", ".join([f"'{label}'" for label in
                                                     duplicate_labels[name_criterion][label_to_import]])
                action += f", overriding the current label(s): {duplicate_labels_string}"
                for duplicate_label in duplicate_labels[name_criterion][label_to_import]:
                    label_to_remove_duplicate_from = centra_labels[duplicate_label]
                    centra_labels_to_update.add(duplicate_label)
                    current_dynamic_criteria = label_to_remove_duplicate_from["dynamic_criteria"]
                    new_dynamic_criteria = \
                        [criterion for criterion in current_dynamic_criteria if not
                            (criterion["op"] == name_criterion.criterion_type and
                             criterion["argument"] == name_criterion.name)]
                    label_to_remove_duplicate_from["dynamic_criteria"] = new_dynamic_criteria
                # remove the duplicate labels list so it wont be iterated over twice
                del duplicate_labels[name_criterion][label_to_import]

            actions_as_strings.append(action)

    # Mark for removal duplicate labels of labels that are mentioned in the CSV for the name criterion but not going
    # to be imported because the name criterion is already labeled with them in Centra
    if not allow_duplicates:
        for name_criterion in duplicate_labels:
            if not duplicate_labels[name_criterion]:
                continue
            for label_that_already_exist, duplicate_labels_list in duplicate_labels[name_criterion].items():
                duplicate_labels_string = ", ".join([f"'{label}'" for label in duplicate_labels_list])
                action = f"Overriding the label(s) {duplicate_labels_string} that are duplicates of the label " \
                         f"'{label_that_already_exist}', for the name criterion {name_criterion}"
                for duplicate_label in duplicate_labels_list:
                    label_to_remove_duplicate_from = centra_labels[duplicate_label]
                    centra_labels_to_update.add(duplicate_label)
                    current_dynamic_criteria = label_to_remove_duplicate_from["dynamic_criteria"]
                    new_dynamic_criteria = \
                        [criterion for criterion in current_dynamic_criteria if not
                            (criterion["op"] == name_criterion.criterion_type and
                             criterion["argument"] == name_criterion.name)]
                    label_to_remove_duplicate_from["dynamic_criteria"] = new_dynamic_criteria
                # remove the duplicate labels list so it wont be iterated over twice
                actions_as_strings.append(action)
    return


def print_summary_and_ask_for_confirmation_for_import_action(num_of_labels_to_import, num_of_labels_to_update,
                                                             actions_as_strings, assets_not_in_centra, env_name):
    """
    Print the actions summary and prompt the user for permission to execute the import and update actions.
    Abort if the permission was denied.
    :return: True if the user approved, False if the user did not approve
    """
    logger.info("--------------PRE EXECUTION SUMMARY---------------")
    if len(assets_not_in_centra) > 0:
        logger.warning(f"The following {len(assets_not_in_centra)} asset(s) were mentioned in the CSV but "
                       f"does not exist in Centra: ")
        for asset_name in assets_not_in_centra:
            logger.warning(asset_name)
        if not args.include_deleted_assets:
            logger.info("If the assets are in Centra in Deleted state, consider re running the script providing "
                        "the --include_deleted_assets flag")
        logger.info("------------------------------------------------------")
    if len(actions_as_strings) == 0:
        logger.info("No actions to take or log")
        sys.exit(0)

    logger.info(f"About to upload labels to the system {env_name}")
    if num_of_labels_to_import:
        logger.info(f"{num_of_labels_to_import} new labels will be created in Centra")
    if num_of_labels_to_update:
        logger.info(f"{num_of_labels_to_update} existing labels will be updated in Centra")
    logger.info("------------------------------------------------------")

    return print_action_summary_and_ask_for_confirmation(actions_as_strings)


def upload_new_labels_to_centra(gc_api, labels_to_create) -> None:
    """
    Format the labels to create in the way that Centra API expects them and upload them to Centra
    :param gc_api: RESTManagementAPI object
    :param labels_to_create: dictionary mapping a new label (key, value) to its criteria (asset_ids, subnets, ips)
    """
    labels_to_upload = list()
    for label_tuple, label_criteria in labels_to_create.items():
        key, value = label_tuple
        criteria = list()sort_labels_for_targets_by_target_types
        criteria += label_criteria.get("dynamic_criteria", list())
        criteria += label_criteria.get("equal_criteria", list())
        label_obj_to_api = {"key": key, "value": value, "criteria": criteria}
        labels_to_upload.append(label_obj_to_api)
    logger.info(f"Uploading {len(labels_to_upload)} label(s) to Centra")
    try:
        gc_api.bulk_create_labels(labels_to_upload)
    except ManagementAPITimeoutError:
        logger.error(f"The request for label creation has timed out")
        logger.info("Do not worry! This does not mean the labels were not uploaded to Centra, only that it "
                    "takes Centra some time to process the labels creation request as the request is big.\n"
                    "To make sure all labels were created successfully in Centra, wait 5 minutes and re run the import "
                    "command with the same input. The script should prompt that no action needs to be taken.\n"
                    "Alternatively, review the labels manually in Centra UI.")
    except ManagementAPIError as e:
        logger.error(f"Error while uploading new labels: {repr(e)}")

# </editor-fold>


# <editor-fold desc="export command">
def export_labels():
    """
    Export command main function
    """
    logger.info("Exporting labels from Centra")
    with initiate_gc_api() as gc_api:
        centra_assets = get_centra_assets(gc_api, args.include_deleted_assets)
        centra_labels = get_centra_labels(gc_api)

        assets_to_static_labels = extract_statically_labeled_assets_from_centra_labels(centra_labels)
        assets_to_dynamic_labels, assets_to_orchestration_labels = \
            identify_dynamically_labeled_assets_and_orchestration_labels(centra_assets, assets_to_static_labels)

        subnets_to_dynamic_labels = extract_subnet_dynamic_criteria_from_centra_labels(centra_labels)

        name_criteria_to_dynamic_labels = extract_name_dynamic_criteria_from_centra_labels(centra_labels)

        assets_export_data, unique_asset_keys = \
            generate_assets_export_data(assets_to_static_labels, assets_to_dynamic_labels,
                                        assets_to_orchestration_labels, centra_assets, args.dont_mark_dynamic,
                                        args.allow_multiple_values, args.export_orchestration_labels,
                                        args.include_deleted_assets)

        subnets_export_data, unique_subnet_keys = \
            generate_subnets_export_data(subnets_to_dynamic_labels, args.allow_multiple_values)

        name_criteria_export_data, unique_name_criteria_keys = \
            generate_name_criteria_export_data(name_criteria_to_dynamic_labels, args.allow_multiple_values)

        # If export_path argument wasn't provided by the user, set it to a default value
        if args.export_file_path:
            export_file_path = string_to_filename(args.export_file_path)
        else:
            time_now = datetime.datetime.now().strftime("%d%m%y_%H_%M_%S")
            export_file_path = string_to_filename(f"{gc_api.get_env_name()}_labels_export_{time_now}.csv")
        try:
            pre_keys_fields = ['Entity', 'Asset ID', 'Asset Status', 'IP Addresses']
            unique_keys = list(unique_asset_keys.union(unique_subnet_keys, unique_name_criteria_keys))
            unique_keys.sort(key=str.lower)
            post_keys_fields = ['Comments']
            with open(export_file_path, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=pre_keys_fields + unique_keys + post_keys_fields)
                writer.writeheader()
                for asset_export_data in assets_export_data:
                    writer.writerow(asset_export_data)
                for subnet_export_data in subnets_export_data:
                    writer.writerow(subnet_export_data)
                for name_criteria_export_data in name_criteria_export_data:
                    writer.writerow(name_criteria_export_data)
        except IOError as error:
            logger.error(f"Error while trying to write export file: {repr(error)}")
            sys.exit(1)
        except Exception as error:
            logger.error(f"Could not export labels: {repr(error)}")
            sys.exit(1)
        logger.info(f"Successfully exported labels from Centra to {export_file_path}")


def extract_statically_labeled_assets_from_centra_labels(centra_labels):
    """
    Iterate over each of Centra labels, and extract from it the list of all the assets that are explicitly labeled by it
    :param centra_labels: a list of all centra label objects
    :return: a dict mapping the asset_id of each asset in Centra to a list of the Labels it is explicitly labeled with
    """
    assets_to_static_labels = defaultdict(list)

    for label in centra_labels:
        for criterion in label["equal_criteria"]:
            explicitly_labeled_asset = criterion["argument"]
            assets_to_static_labels[explicitly_labeled_asset].append(Label(label["key"], label["value"]))
    return assets_to_static_labels


def identify_dynamically_labeled_assets_and_orchestration_labels(centra_assets, assets_to_static_labels):
    """
    Identify assets that are labeled dynamically. This is done by iterating over all the the labels each asset is
    labeled with, and check which of them is not in this asset's list of static labels
    :param centra_assets: list of all Centra assets
    :param assets_to_static_labels: a dict mapping asset_ids to a list of the labels they are explicitly labeled with
    :return:
        assets_to_dynamic_labels - a dict mapping asset_ids to a list of the Labels they are dynamically labeled with
        assets_to_orchestration_labels - a dict mapping asset_ids to a list of the Orchestration Labels they are
        labeled with
    """
    assets_to_dynamic_labels = defaultdict(list)
    assets_to_orchestration_labels = defaultdict(list)
    for asset in centra_assets:
        asset_id = asset["id"]
        for label_obj in asset["labels"]:
            label = Label(label_obj["key"], label_obj["value"])
            if label not in assets_to_static_labels[asset_id]:
                if is_orchestration_label(label.key):
                    assets_to_orchestration_labels[asset_id].append(label)
                else:
                    # Labels imported from orchestration tags fall under Dynamic labels
                    assets_to_dynamic_labels[asset_id].append(label)
    return assets_to_dynamic_labels, assets_to_orchestration_labels


def extract_subnet_dynamic_criteria_from_centra_labels(centra_labels):
    """
    Iterate over each of Centra labels, and extract from it the list of all the subnet dynamic criteria
    :param centra_labels: a list of all centra label objects
    :return: a dict mapping subnet / ip to a list of the labels they are explicitly labeled with
        (subnet / ip: [(key: value), (key2: value2)]
    """
    subnets_to_dynamic_labels = defaultdict(list)
    for label in centra_labels:
        for criterion in label["dynamic_criteria"]:
            if criterion["op"] == "SUBNET":
                subnets_to_dynamic_labels[criterion["argument"]].append(Label(label["key"], label["value"]))
    return subnets_to_dynamic_labels


def extract_name_dynamic_criteria_from_centra_labels(centra_labels):
    """
    Iterate over each of Centra labels, and extract from it the list of all the name dynamic criteria
    :param centra_labels: a list of all centra label objects
    :return: a dict mapping name dynamic criterion to a list of the labels they are explicitly labeled with
        (NameCriterion: [(key: value), (key2: value2)]
    """
    name_criterion_to_labels = defaultdict(list)
    for label in centra_labels:
        for criterion in label["dynamic_criteria"]:
            if criterion["field"] == "name":
                name_criterion = NameCriterion(criterion['argument'], criterion['op'])
                name_criterion_to_labels[name_criterion].append(Label(label["key"], label["value"]))
    return name_criterion_to_labels


def generate_assets_export_data(assets_to_static_labels, assets_to_dynamic_labels, assets_to_orchestration_labels,
                                centra_assets, dont_mark_dynamic, allow_multiple_values, export_orchestration_labels,
                                include_delete_assets):
    """
    Iterate over assets_to_static_labels and assets_to_dynamic_labels to generate the data to export for all the labeled
    assets in Centra
    :param include_delete_assets: Whether deleted assets are included in the export command.
    :param assets_to_static_labels: a dict mapping the asset_id of each asset in Centra to a list of the Labels it is
    explicitly labeled with
    :param assets_to_dynamic_labels: a dict mapping asset_ids to a list of the labels they are dynamically labeled with
    :param assets_to_orchestration_labels: a dict mapping asset_ids to a list of the orchestration labels they are
    labeled with
    :param centra_assets: a list of all centra label objects
    :param dont_mark_dynamic: Boolean. Whether to mark labels assigned dynamically with DYNAMIC_TAG
    :param allow_multiple_values: Boolean. Whether to separate multiple values for a specific key with commas (=allow)
    or place them in the command (=do not allow)
    :param export_orchestration_labels: Boolean. Whether to export also orchestration metadata labels for assets
    :return:
    - A list of dictionaries, each dictionary maps an asset_id to it's data to export
    - A set of the unique label keys seen for assets
    """

    assets_export_data = list()
    unique_asset_keys = set()

    centra_asset_id_to_asset_obj = {asset["id"]: asset for asset in centra_assets}

    for asset_id in assets_to_static_labels:
        try:
            asset = centra_asset_id_to_asset_obj[asset_id]
        except KeyError as e:
            if not include_delete_assets:
                logger.debug(f"Skipping the assets '{asset_id}' because it is deleted and include_delete_assets is "
                             f"set to False.")
                continue
            else:  # There is no reason for the asset to be missing if include_delete_assets is True
                logger.error("Something is wrong. Please contact Guardicore support")
                raise KeyError(e)
        asset_export_data = dict()
        asset_comments = list()

        for label in assets_to_static_labels[asset_id]:
            if label.key not in asset_export_data:
                asset_export_data[label.key] = label.value
            elif allow_multiple_values:
                asset_export_data[label.key] += f", {label.value}"
            else:
                asset_comments.append(f"Duplicate value '{label.value}' is associated with the key '{label.key}'")
            unique_asset_keys.add(label.key)

        for label in assets_to_dynamic_labels[asset_id]:
            value = label.value
            if not dont_mark_dynamic:
                value = value + DYNAMIC_TAG
            if label.key not in asset_export_data:
                asset_export_data[label.key] = value
            elif allow_multiple_values:
                asset_export_data[label.key] += f", {value}"
            else:
                asset_comments.append(f"Duplicate value '{value}' is associated with the key '{label.key}'")
            unique_asset_keys.add(label.key)

        if export_orchestration_labels:
            for label in assets_to_orchestration_labels[asset_id]:
                if label.key not in asset_export_data:
                    asset_export_data[label.key] = label.value
                elif allow_multiple_values:
                    asset_export_data[label.key] += f", {label.value}"
                else:
                    asset_comments.append(f"Duplicate value '{label.value}' is associated with the key '{label.key}'")
                unique_asset_keys.add(label.key)

        if asset_comments:
            asset_export_data['Comments'] = '. '.join(asset_comments)

        # Enrich asset_export_data with asset details
        asset_export_data['Entity'] = asset['name']
        asset_export_data['Asset ID'] = asset['id']
        asset_export_data['IP Addresses'] = ', '.join(asset.get('ip_addresses', list()))
        asset_export_data['Asset Status'] = asset['status']

        assets_export_data.append(asset_export_data)

    return assets_export_data, unique_asset_keys


def generate_subnets_export_data(subnets_to_dynamic_labels, allow_multiple_values):
    """
    Iterate over subnets_to_dynamic_labels to generate the data to export for all the labeled subnets and ips in Centra
    :param subnets_to_dynamic_labels: a dict mapping subnets / ips to a list of the labels they are dynamically labeled
    with
    :param allow_multiple_values: Boolean. Whether to separate multiple values for a specific key with commas (=allow)
    or place them in the command (=do not allow)
    :return:
    - subnets_export_data - A list of dictionaries, each dictionary maps an subnet to it's data to export
    - unique_label_keys - A set of the unique label keys seen for subnets
    """

    subnets_export_data = list()
    unique_label_keys = set()

    for subnet in subnets_to_dynamic_labels:
        subnet_export_data = dict()
        subnet_comments = list()

        for label in subnets_to_dynamic_labels[subnet]:
            value = label.value
            if label.key not in subnet_export_data:
                subnet_export_data[label.key] = value
            elif allow_multiple_values:
                subnet_export_data[label.key] += f", {value}"
            else:
                subnet_comments.append(f"Duplicate value '{value}' is associated with the key '{label.key}'")
            unique_label_keys.add(label.key)

        if subnet_comments:
            subnet_export_data['Comments'] = '. '.join(subnet_comments)

        subnet_export_data['Entity'] = subnet

        subnets_export_data.append(subnet_export_data)

    return subnets_export_data, unique_label_keys


def generate_name_criteria_export_data(name_criteria_to_dynamic_labels, allow_multiple_values):
    """
    Iterate over name_criteria_to_dynamic_labels to generate the data to export for all the name criteria of labels
    in Centra
    :param name_criteria_to_dynamic_labels: a dict mapping NameCriterion to a list of the labels they are dynamically
    labeled with
    :param allow_multiple_values: Boolean. Whether to separate multiple values for a specific key with commas (=allow)
    or place them in the command (=do not allow)
    :return:
    - name_criteria_export_data - A list of dictionaries, each dictionary maps an name criteria to it's data to export
    - unique_label_keys - A set of the unique label keys seen for name criteria
    """

    name_criteria_export_data = list()
    unique_label_keys = set()

    for name_criterion in name_criteria_to_dynamic_labels:
        name_criterion_export_data = dict()
        name_criterion_comments = list()

        for label in name_criteria_to_dynamic_labels[name_criterion]:
            value = label.value
            if label.key not in name_criteria_export_data:
                name_criterion_export_data[label.key] = value
            elif allow_multiple_values:
                name_criterion_export_data[label.key] += f", {value}"
            else:
                name_criterion_comments.append(f"Duplicate value '{value}' is associated with the key '{label.key}'")
            unique_label_keys.add(label.key)

        if name_criterion_comments:
            name_criterion_export_data['Comments'] = '. '.join(name_criterion_comments)

        name_criterion_export_data['Entity'] = name_criterion.to_export_string()

        name_criteria_export_data.append(name_criterion_export_data)

    return name_criteria_export_data, unique_label_keys
# </editor-fold>


# <editor-fold desc="cleanup command">
def cleanup_labels():
    """
    Cleanup labels main function
    """
    if args.empty:
        empty_all_labels_in_centra()
    else:
        delete_all_labels_from_centra()


def empty_all_labels_in_centra() -> None:
    """
    Remove all the criteria and assets from all the labels in Centra
    """
    logger.info("Removing all the criteria and assets from all the labels in Centra")
    with initiate_gc_api() as gc_api:
        centra_labels_raw = get_centra_labels(gc_api)
        centra_labels_without_orch_labels = \
            [label for label in centra_labels_raw if not is_orchestration_label(label['key'])]

        actions_as_strings = [f"About to empty the label '{Label(label['key'], label['value'])}' with the label_id "
                              f"{label['id']}" for label in centra_labels_without_orch_labels]

        env_name = gc_api.get_env_name()
        if print_summary_and_ask_for_confirmation_for_cleanup_action(len(centra_labels_raw), actions_as_strings,
                                                                     env_name, empty_labels=True):
            for label in centra_labels_without_orch_labels:
                # Get the asset ids of all the assets in the label. This is necessary because the update
                # label function does not remove equal criteria
                assets_in_label = [criterion["argument"] for criterion in label['equal_criteria']]
                try:
                    gc_api.remove_assets_from_label(assets_in_label, label['key'], label['value'])
                    gc_api.update_visibility_label_by_label_id(label['id'], label['key'], label['value'], [])
                except ManagementAPIError as e:
                    logger.error(repr(e))
            logger.info(f"Finished emptying labels in {env_name}.")


def delete_all_labels_from_centra() -> None:
    """
    Delete all the labels in Centra
    """
    logger.info("Deleting all the labels in Centra")
    with initiate_gc_api() as gc_api:
        centra_labels_raw = get_centra_labels(gc_api)
        centra_label_ids = [label['id'] for label in centra_labels_raw]
        actions_as_strings = [f"About to delete the label {Label(label['key'], label['value'])} with the label_id "
                              f"{label['id']} from Centra" for label in centra_labels_raw]
        env_name = gc_api.get_env_name()
        if print_summary_and_ask_for_confirmation_for_cleanup_action(len(centra_label_ids), actions_as_strings,
                                                                     env_name):
            try:
                gc_api.delete_multiple_labels(centra_label_ids)
            except ManagementAPIError as e:
                logger.warning(e.args[0]["error_dump"])

            logger.info(f"Finished deleting labels from {env_name}.")


def print_summary_and_ask_for_confirmation_for_cleanup_action(num_of_labels_to_cleanup: int,
                                                              actions_as_strings: List[str], env_name: str,
                                                              empty_labels: bool = False) -> bool:
    """
    Print the actions summary and prompt the user for permission to execute the labels cleanup action.
    :return: True if the user approved, False if the user did not approve
    """
    logger.info("--------------PRE EXECUTION SUMMARY---------------")
    if empty_labels:
        logger.info(f"About to remove all the criteria from all the {num_of_labels_to_cleanup} labels in the "
                    f"system {env_name}")
    else:
        logger.info(f"About to delete all the {num_of_labels_to_cleanup} labels in the system {env_name}")
    logger.info("------------------------------------------------------")

    return print_action_summary_and_ask_for_confirmation(actions_as_strings)

# </editor-fold>


# <editor-fold desc="summarize command">
def summarize_label_subnet_criteria():
    """
    Summarize command main function
    """
    with initiate_gc_api() as gc_api:

        if args.all:
            logger.info("Summarizing the subnet dynamic criteria of all the labels in Centra")
            centra_labels_raw = get_centra_labels(gc_api)
        elif args.keys:
            logger.info(f"Summarizing the subnet dynamic criteria of all the labels in Centra that has one of the "
                        f"following keys: {', '.join(args.keys)}")
            centra_labels_raw = get_centra_labels(gc_api, filter_keys=args.keys)
        else:
            logger.info(f"Summarizing the subnet dynamic criteria of the labels: {', '.join(args.labels)}")
            centra_labels_raw = list()
            for label in args.labels:
                try:
                    key = label.split(':')[0].strip()
                    value = label.split(':')[1].strip()
                except ValueError:
                    logger.error(f"The label {label} provided is not legal. Label should be provided in the "
                                 f"following way: key: value, i.e. App: Ecomm")
                    logger.info("Aborting..")
                    sys.exit(1)
                label_obj = get_individual_centra(gc_api, key, value)
                if label_obj:
                    centra_labels_raw.append(label_obj)
                else:
                    logger.warning(f"The label {key}: {value} was not found in Center")

        if len(centra_labels_raw) == 0:
            logger.info("No actions to be taken. Exiting..")
            sys.exit(0)

        labels_with_updates = list()
        actions_as_strings = list()
        for label in centra_labels_raw:
            if summarize_the_subnet_criteria_of_a_label(label):
                actions_as_strings.append(f"Summarizing the subnet dynamic criteria of the label {label['key']}: "
                                          f"{label['value']}")
                labels_with_updates.append(label)

        env_name = gc_api.get_env_name()
        if len(labels_with_updates) > 0:
            if print_summary_and_ask_for_confirmation_for_summarize_action(len(centra_labels_raw), actions_as_strings,
                                                                           env_name):
                for label in labels_with_updates:
                    try:
                        gc_api.update_visibility_label(label)
                    except ManagementAPIError as e:
                        logger.error(repr(e))
                logger.info(f"Finished summarizing labels in {env_name}.")
        else:
            logger.info(f"No labels required summarization in {env_name}.")


def get_individual_centra(gc_api, key, value):
    """
    Query Centra API for a single label. If found, return the label object, otherwise return None
    :param key: The label key
    :param value: The label value
    :param gc_api: RESTManagementAPI object
    :return: The label object
    """
    logging.info(f"Trying to fetch the label '{key}: {value}' from Centra")
    response = gc_api.list_visibility_labels(dynamic_criteria_limit=DYNAMIC_CRITERIA_LIMIT,
                                             limit=LABEL_OBJECTS_TO_GET_AT_ONCE, key=key, value=value)
    for label in response["objects"]:
        if label['key'] == key and label['value'] == value:
            return label
    return None


def summarize_the_subnet_criteria_of_a_label(label):
    """
    Summarize the subnet dynamic criteria of the provided label
    :param label: Label object as returned from Centra API. The label who's criteria's will be summarized
    :return: True if the summarization action had an effect, False otherwise
    """
    current_dynamic_criteria = label["dynamic_criteria"]
    new_dynamic_criteria = list()
    subnet_criteria_in_label = list()
    for criterion in current_dynamic_criteria:
        if criterion["op"] == "SUBNET":
            subnet_criteria_in_label.append(criterion["argument"])
        else:
            # Non subnets criteria are copied "as is"
            new_dynamic_criteria.append(criterion)
    if subnet_criteria_in_label:
        subnet_criteria_in_label_as_string = ', '.join(subnet_criteria_in_label)[:1000] + '..' if \
            len(', '.join(subnet_criteria_in_label)) > 1000 else ', '.join(subnet_criteria_in_label)
        logger.debug(f"Summarizing the current subnet dynamic criteria of the label {label['key']}: {label['value']}. "
                     f"Current criteria: {subnet_criteria_in_label_as_string}.")
        summarized_subnet_criteria_in_label = IPSet(subnet_criteria_in_label)
        summarized_subnet_criteria_as_strings = ', '.join([str(cidr) for cidr in
                                                          summarized_subnet_criteria_in_label.iter_cidrs()])
        summarized_subnet_criteria_as_strings = summarized_subnet_criteria_as_strings[:1000] + '..' if \
            len(summarized_subnet_criteria_as_strings) > 1000 else summarized_subnet_criteria_as_strings
        logger.debug(f"New subnet criteria after summarization: {summarized_subnet_criteria_as_strings}")
        for cidr in summarized_subnet_criteria_in_label.iter_cidrs():
            new_dynamic_criteria.append({"field": "numeric_ip_addresses", "op": "SUBNET", "argument": str(cidr)})

    if len(new_dynamic_criteria) == len(label["dynamic_criteria"]):
        logger.debug(f"The summarization action did not have an effect on the label {label['key']}: {label['value']}")
        return False
    elif len(new_dynamic_criteria) < len(label["dynamic_criteria"]):
        label["dynamic_criteria"] = new_dynamic_criteria
        return True
    else:
        assert False, "Something is wrong. The new dynamic criteria is bigger than the old one. Please contact " \
                      "Guardicore support"


def print_summary_and_ask_for_confirmation_for_summarize_action(num_of_labels_to_summarize, actions_as_strings,
                                                                env_name):
    """
    Print the actions summary and prompt the user for permission to execute the labels summarization action.
    Abort if the permission was denied.
    :return: True if the user approved, False if the user did not approve
    """
    logger.info("--------------PRE EXECUTION SUMMARY---------------")
    logger.info(f"About to summarize the subnet dynamic criteria of {num_of_labels_to_summarize} labels in "
                f"the system {env_name}")
    logger.info("------------------------------------------------------")

    return print_action_summary_and_ask_for_confirmation(actions_as_strings)

# </editor-fold>


# <editor-fold desc="remove command">
def remove_labels_from_csv():
    """
    Remove labels main function.
    """
    raw_labels_to_remove = parse_labels_csv(args.labels_file_path, args.ignore_labels_export_metadata,
                                            allow_duplicates=True)
    raw_labels_to_remove_for_assets, raw_labels_to_remove_for_subnets, labels_to_remove_for_name_criteria = \
        sort_labels_for_targets_by_target_types(raw_labels_to_remove, args.ignore_name_criteria)

    with initiate_gc_api() as gc_api:
        centra_assets_raw = get_centra_assets(gc_api, include_deleted_assets=args.include_deleted_assets)
        centra_assets = {asset["id"]: asset for asset in centra_assets_raw}

        centra_labels_raw = get_centra_labels(gc_api)
        centra_labels = {Label(label_obj["key"], label_obj["value"]): label_obj for label_obj in centra_labels_raw if
                         not is_orchestration_label(label_obj['key'])}

        labels_to_remove_for_assets, assets_not_in_centra = \
            process_raw_labels_to_remove_for_assets(raw_labels_to_remove_for_assets, centra_labels, centra_assets)

        labels_to_remove_for_subnets = \
            process_raw_labels_to_remove_for_subnets(raw_labels_to_remove_for_subnets, centra_labels,
                                                     args.treat_subnets_as_networks)

        labels_to_remove_for_name_criteria = \
            process_raw_labels_to_remove_for_name_criteria(labels_to_remove_for_name_criteria, centra_labels)

        centra_labels_to_update = set()  # A set to store all the labels that need to be modified
        actions_as_strings = list()  # A list to store the actions to be taken as strings

        labels_to_assets_to_remove_mapping = \
            generate_remove_actions_for_assets(labels_to_remove_for_assets, centra_assets, actions_as_strings)

        generate_remove_actions_for_subnets(labels_to_remove_for_subnets, centra_labels, centra_labels_to_update,
                                            actions_as_strings, args.treat_subnets_as_networks)

        generate_remove_actions_for_name_criteria(labels_to_remove_for_name_criteria, centra_labels,
                                                  centra_labels_to_update, actions_as_strings)

        env_name = gc_api.get_env_name()

        num_of_labels_with_updates = len(centra_labels_to_update | set(labels_to_assets_to_remove_mapping.keys()))
        if print_summary_and_ask_for_confirmation_for_remove_action(num_of_labels_with_updates, actions_as_strings,
                                                                    assets_not_in_centra, env_name):
            if centra_labels_to_update:
                update_centra_labels(gc_api, centra_labels_to_update, centra_labels)
            if labels_to_remove_for_assets:
                remove_assets_from_labels(gc_api, labels_to_assets_to_remove_mapping)

            logger.info(f"Finished deleting labels in {env_name}.")


def process_raw_labels_to_remove_for_assets(raw_labels_to_remove_for_assets, centra_labels: Dict[Label, Dict[str, Any]],
                                            centra_assets: Dict[str, Dict[str, Any]]) -> \
        Tuple[Dict[str, List[Label]], set]:
    """
    Process the raw labels to remove for assets. For each asset:
    1. Validate whether it is indeed a legal asset that exists in Centra
    2. Create a list of all the new labels that should be removed from it
    :param raw_labels_to_remove_for_assets: a dictionary mapping every asset to the list of it's labels to remove
    :param centra_labels: dict containing all Centra labels (Label: label_obj)
    :param centra_assets: dict containing all Centra assets (asset_id: asset_obj)
    :return:
        labels_to_remove - dict mapping each asset_id to it's labels to remove
        assets_not_in_centra - list of assets that were mentioned in the CSV but were not found in Centra
    """
    # Locate assets that were mentioned in the CSV but are missing from Centra
    assets_not_in_centra = set()
    asset_name_to_asset_ids = create_asset_name_to_asset_ids_mapping(centra_assets,
                                                                     set(raw_labels_to_remove_for_assets.keys()))
    for potential_asset in raw_labels_to_remove_for_assets:
        if potential_asset not in asset_name_to_asset_ids:
            logger.warning(f"The asset {potential_asset} was not found in Centra.")
            assets_not_in_centra.add(potential_asset)
    # Remove non existing assets from raw_labels_to_remove_for_assets
    for asset_not_in_centra in assets_not_in_centra:
        del raw_labels_to_remove_for_assets[asset_not_in_centra]

    current_explicit_labels_for_assets = map_assets_to_explicit_labels(centra_labels, asset_name_to_asset_ids)
    labels_to_remove = defaultdict(list)
    for asset_name, raw_labels_to_remove_for_asset in raw_labels_to_remove_for_assets.items():
        # There might be more than one asset with the same name, so it is necessary to iterate over all those
        for asset_id in asset_name_to_asset_ids[asset_name]:
            current_labels_for_asset = current_explicit_labels_for_assets.get(asset_id, list())
            for label_to_remove in raw_labels_to_remove_for_asset:
                if label_to_remove not in current_labels_for_asset:
                    logger.info(f"The asset {asset_name} with the asset_id '{asset_id}' is not labeled with the label "
                                f"'{label_to_remove}', no need to remove it")
                else:
                    labels_to_remove[asset_id].append(label_to_remove)

    return labels_to_remove, assets_not_in_centra


def process_raw_labels_to_remove_for_subnets(raw_labels_to_remove_for_subnets: Dict[IPNetwork, List[Label]],
                                             centra_labels: Dict[Label, Dict[str, Any]],
                                             treat_subnets_as_networks: bool) -> Dict[IPNetwork, List[Label]]:
    """
    Process the raw labels to remove for subnets. Create for each subnet a list of all the labels that should be
    removed from it
    :param treat_subnets_as_networks: If True, subnets will be treated as network objects. This means that the
    subnet will be counted as if it is already labeled with some label if the label current criteria covers this subnet.
    For example - 10.0.0.1/32 will be counted inside the label App: Ecomm if the App: Ecomm has a dynamic subnet
    criterion of 10.0.0.0/8.
    If False, only exact matches will be counted - 10.0.0.1/32 not already covered by 10.0.0.0/8
    :param raw_labels_to_remove_for_subnets: a dictionary mapping every subnet to the list of it's labels to remove
    :param centra_labels: dict containing all Centra labels ((key, value): label_obj)
    :return:
        labels_to_remove - dict mapping each subnet to it's labels to remove
    """
    labels_to_remove = defaultdict(list)
    if treat_subnets_as_networks:
        current_labels_for_subnets = \
            map_current_labels_for_subnets_as_networks(centra_labels, set(raw_labels_to_remove_for_subnets.keys()))
    else:
        current_labels_for_subnets = \
            map_current_labels_for_subnets_as_strings(centra_labels, set(raw_labels_to_remove_for_subnets.keys()))

    for subnet, raw_labels_to_remove_for_subnet in raw_labels_to_remove_for_subnets.items():
        current_labels_for_subnet = current_labels_for_subnets.get(subnet, list())
        for label_to_remove in raw_labels_to_remove_for_subnet:
            if label_to_remove not in current_labels_for_subnet:
                logger.info(f"The subnet {subnet} is not in the criteria of the label '{label_to_remove}', no need to "
                            f"remove it")
            else:
                labels_to_remove[subnet].append(label_to_remove)

    return labels_to_remove


def process_raw_labels_to_remove_for_name_criteria(
        raw_labels_to_remove_for_name_criteria: Dict[NameCriterion, List[Label]],
        centra_labels: Dict[Label, Dict[str, Any]]) -> Dict[NameCriterion, List[Label]]:
    """
    Process the raw labels to remove for name criteria. For each NameCriterion, Create a list of all the labels that
    should be removed from it
    :param raw_labels_to_remove_for_name_criteria: a dictionary mapping each NameCriterion to the list of it's
    labels to remove
    :param centra_labels: dict containing all Centra labels (Label: label_obj)
    :return: a dict mapping each NameCriterion to it's labels to remove
    """
    labels_to_remove = defaultdict(list)
    current_labels_for_name_criteria = \
        map_current_labels_for_name_criteria(centra_labels, set(raw_labels_to_remove_for_name_criteria.keys()))

    for name_criterion, raw_labels_to_remove_for_name_criterion in raw_labels_to_remove_for_name_criteria.items():
        current_labels_for_name_criterion = current_labels_for_name_criteria.get(name_criterion, list())
        for label_to_remove in raw_labels_to_remove_for_name_criterion:
            if label_to_remove not in current_labels_for_name_criterion:
                logger.info(f"The name criterion {name_criterion} is not in the criteria of the label "
                            f"'{label_to_remove}', no need to remove it")
            else:
                labels_to_remove[name_criterion].append(label_to_remove)

    return labels_to_remove


def generate_remove_actions_for_assets(labels_to_remove_for_assets: Dict[str, List[Label]],
                                       centra_assets: Dict[str, Dict[str, Any]],
                                       actions_as_strings: List) -> Dict[Label, List[str]]:
    """
    Iterate over labels_to_remove_for_assets:
     - Populate labels_to_assets_to_remove_mapping with the asset_ids that should be removed from each Centra label.
     - Populate actions_as_strings with actions to be taken as string.
    :param labels_to_remove_for_assets: a dict mapping each asset_id to a list the labels it should be removed from
    :param actions_as_strings: An empty list to store actions to be taken as string (i.e. "Deleting the label
    'App: Ecomm' for the asset 'DC-10' with asset_id xxxx").
    :param centra_assets: dict containing all Centra assets (asset_id: asset_obj)
    :return: labels_to_assets_to_remove_mapping - a dict mapping labels to a list of asset_ids to remove from them
    """
    labels_to_assets_to_remove_mapping = defaultdict(list)
    for asset_id, labels_to_remove_the_asset_from in labels_to_remove_for_assets.items():
        asset_name = centra_assets[asset_id]['vm_name'].lower()
        for label in labels_to_remove_the_asset_from:
            actions_as_strings.append(f"Removing the asset {asset_name} with asset_id '{asset_id}' from the label "
                                      f"'{label}'")
            labels_to_assets_to_remove_mapping[label].append(asset_id)
    return labels_to_assets_to_remove_mapping


def generate_remove_actions_for_subnets(labels_to_remove_for_subnets: Dict[IPNetwork, List[Label]],
                                        centra_labels: Dict[Label, Dict[str, Any]], centra_labels_to_update: Set,
                                        actions_as_strings: List[str], treat_subnets_as_networks: bool) -> None:
    """
    Process the labels_to_remove_for_subnets:
     - Apply the subnets deletion on the label objects in centra_labels, as a preparation to send those to the API.
     - Populate centra_labels_with_updates with Centra labels that have updates
     - Populate actions_as_strings with actions to be taken as string.
    :param labels_to_remove_for_subnets: a dict mapping each subnet to a list of the labels it should be removed from
    :param treat_subnets_as_networks: If True, subnets will be removed from labels using
    remove_subnet_as_network_from_label_criteria, otherwise with remove_subnet_as_string_from_label_criteria
    :param actions_as_strings: list of actions to be taken as string  (i.e. "Importing the label 'App: Ecomm' for
    '10.0.0.30/32'").
    :param centra_labels_to_update: an empty that will be populated with labels that have updates, (the actual updates
    are made on centra_labels dict)
    :param centra_labels: dict containing all Centra labels (Label: label_obj). Changes to labels that should be
    updated are performed on label objects in this dict
    """

    for subnet, labels_to_remove_for_subnet in labels_to_remove_for_subnets.items():
        for label in labels_to_remove_for_subnet:
            actions_as_strings.append(f"Deleting the label '{label}' from the subnet {subnet}")
            if treat_subnets_as_networks:
                remove_subnet_as_network_from_label_criteria(subnet, centra_labels[label])
            else:
                remove_subnet_as_string_from_label_criteria(subnet, centra_labels[label])
                centra_labels_to_update.add(label)


def generate_remove_actions_for_name_criteria(labels_to_remove_for_name_criteria: Dict[NameCriterion, List[Label]],
                                              centra_labels: Dict[Label, Dict[str, Any]],
                                              centra_labels_to_update: Set[Label],
                                              actions_as_strings: List[str]) -> None:
    """
    Process the labels_to_remove_for_name_criteria:
     - Apply the criteria deletion on the label objects in centra_labels, as a preparation to send those to the API.
     - Populate centra_labels_with_updates with Centra labels that have updates
     - Populate actions_as_strings with actions to be taken as string.
    :param labels_to_remove_for_name_criteria: a dict mapping each name criteria to a list of the labels it needs to
    be removed from
    :param actions_as_strings: list of actions to be taken as string  (i.e. "Adding the criteria 'Asset name starts
    with 'Ecomm'' to the label 'App: Ecomm'").
    :param centra_labels_to_update: a set of Labels pointing to the Centra labels that have updates (the actual updates
    are made on centra_labels dict)
    :param centra_labels: dict containing all Centra labels (Label: label_obj). Changes to labels that should be
    updated are performed on label objects in this dict
    """
    for name_criterion, labels_to_remove_for_name_criteria in labels_to_remove_for_name_criteria.items():
        for label in labels_to_remove_for_name_criteria:
            actions_as_strings.append(f"Removing the criterion \"{name_criterion}\" from the criteria of the "
                                      f"label '{label}'")
            label_to_remove_from = centra_labels[label]
            centra_labels_to_update.add(label)
            current_dynamic_criteria = label_to_remove_from["dynamic_criteria"]
            new_dynamic_criteria = \
                [criterion for criterion in current_dynamic_criteria if not
                    (criterion["op"] == name_criterion.criterion_type and
                     criterion["argument"] == name_criterion.name)]
            label_to_remove_from["dynamic_criteria"] = new_dynamic_criteria


def print_summary_and_ask_for_confirmation_for_remove_action(num_of_labels_to_update: int,
                                                             actions_as_strings: List[str],
                                                             assets_not_in_centra: Set[str], env_name: str) -> bool:
    """
    Print the actions summary and prompt the user for permission to execute the label deletion actions.
    Abort if the permission was denied.
    :return: True if the user approved, False if the user did not approve
    """
    logger.info("--------------PRE EXECUTION SUMMARY---------------")
    if len(assets_not_in_centra) > 0:
        logger.warning(f"The following {len(assets_not_in_centra)} asset(s) were mentioned in the CSV but "
                       f"does not exist in Centra: ")
        for asset_name in assets_not_in_centra:
            logger.warning(asset_name)
        if not args.include_deleted_assets:
            logger.info("If the assets are in Centra in Deleted state, consider re running the script providing "
                        "the --include_deleted_assets flag")
        logger.info("------------------------------------------------------")
    if len(actions_as_strings) == 0:
        logger.info("No actions to take or log")
        sys.exit(0)

    logger.info(f"About to remove labels from to the system {env_name}")
    if num_of_labels_to_update:
        logger.info(f"{num_of_labels_to_update} existing labels will be updated in Centra")
    logger.info("------------------------------------------------------")

    return print_action_summary_and_ask_for_confirmation(actions_as_strings)


# </editor-fold>


def get_args_parser():
    arg_parser = ArgumentParser(description="Labeling tool for Guardicore Centra")
    subparsers = arg_parser.add_subparsers(dest='action', description="Select the desired action")
    # import labels command args
    do_import = subparsers.add_parser("import", help="Import labels for Assets, IPs, Subnets and name criteria "
                                                     "from a CSV file")
    do_import.add_argument("-p", "--labels_file_path", required=True, help="Labels import CSV file path")
    do_import.add_argument("--allow_duplicates", help="Do not override duplicate labels for the same key",
                           action="store_true")
    do_import.add_argument("--treat_subnets_as_networks", action="store_true",
                           help="Treat subnet dynamic criteria as networks instead of as strings when importing and "
                                "overriding duplicate labels")
    do_import.add_argument("--ignore_name_criteria", action="store_true",
                           help="Upload targets with '*' signs as normal assets and not as name dynamic criteria")
    do_import.add_argument("--include_deleted_assets", help="Import labels also for deleted assets",
                           action="store_true")
    do_import.add_argument("--ignore_labels_export_metadata", action="store_true",
                           help=f"Ignore labels export metadata columns and cells containing the {DYNAMIC_TAG} mark. "
                                f"This is necessary to allow importing the CSV resulted from the export command "
                                f"without any manual CSV modifications")
    add_common_args(do_import)
    do_import.set_defaults(func=import_labels_from_csv)
    # Export labels command args
    do_export = subparsers.add_parser("export", help="Export the labels of assets, subnets, ips and name criteria "
                                                     " from Centra to an import-like CSV file")
    do_export.add_argument("-p", "--export_file_path", help="File name or path to export labels to")
    do_export.add_argument("--dont_mark_dynamic", help="Do not mark label values that were assigned dynamically",
                           action="store_true")
    do_export.add_argument("--allow_multiple_values", action="store_true",
                           help="Allow exporting multiple values per key, separated by commas")
    do_export.add_argument("--export_orchestration_labels", help="Export also orchestration metadata labels",
                           action="store_true")
    do_export.add_argument("--include_deleted_assets", help="Export labels also for deleted assets",
                           action="store_true")
    do_export.set_defaults(func=export_labels)
    add_common_args(do_export)
    # cleanup labels command args
    do_cleanup = subparsers.add_parser("cleanup", help="Delete all the labels in Centra")
    do_cleanup.add_argument("-e", "--empty", action='store_true',
                            help="Instead of deleting all the labels, remove all the assets and dynamic criteria from "
                                 "the labels in Centra, leaving only the labels themselves")
    do_cleanup.set_defaults(func=cleanup_labels)
    # summarize labels command args
    do_summarize = subparsers.add_parser("summarize", help="Summarize the subnet dynamic criteria of labels in Centra")
    scope = do_summarize.add_mutually_exclusive_group(required=True)
    scope.add_argument('--all', action='store_true', help="Summarize the subnet dynamic criteria of all the labels"
                                                          "in Centra")
    scope.add_argument('--keys', nargs='+',
                       help="Scope the summarize action only to labels that have one of the provided keys")
    scope.add_argument('--labels', nargs='+', help="Scope the summarize action only to the provided labels")
    do_summarize.set_defaults(func=summarize_label_subnet_criteria)
    add_common_args(do_summarize)
    # remove labels command args
    do_remove = subparsers.add_parser("remove", help="Ingest a CSV file to remove Assets, IPs, Subnets and name "
                                                     "criteria from labels")
    do_remove.add_argument("-p", "--labels_file_path", required=True, help="Labels to remove CSV file path")
    do_remove.add_argument("--treat_subnets_as_networks", action="store_true",
                           help="Treat subnet dynamic criteria as networks instead of as strings when removing them "
                                "from labels")
    do_remove.add_argument("--ignore_name_criteria", action="store_true",
                           help="Treat targets with '*' signs as normal assets and not as name dynamic criteria")
    do_remove.add_argument("--include_deleted_assets", help="Remove labels also for deleted assets",
                           action="store_true")
    do_remove.add_argument("--ignore_labels_export_metadata", action="store_true",
                           help=f"Ignore labels export metadata columns and cells containing the {DYNAMIC_TAG} mark. "
                                f"This is necessary to allow using data in a CSV resulted from the export command "
                                f"without additional data modifications")
    do_remove.set_defaults(func=remove_labels_from_csv)
    add_common_args(do_remove)
    return arg_parser


def add_common_args(parser: ArgumentParser) -> None:
    """Add the arguments that are common to all the script sub commands to an argument parser"""
    parser.add_argument("-m", "--management_address", help="Management Server FQDN or IP")
    parser.add_argument("-u", "--management_username", help="Centra API username")
    parser.add_argument("--management_port", help="Override default Centra API port", default=443, type=int)
    parser.add_argument("-v", "--verbose", action="store_true", help="Output debugging information")
    parser.add_argument("--log_file_path", help="Log also to a file in the provided path. '*' sign in the path will "
                                                "be replaced with the current time")
    parser.add_argument("--ini_file_path", help="Specify a custom ini file path", default=CONF_PATH)


if __name__ == '__main__':
    args_parser = get_args_parser()
    args = args_parser.parse_args()
    if not args.action:
        args_parser.print_help()
        sys.exit()

    #logger = initiate_logger(verbose=args.verbose, log_file_path=args.log_file_path)
    logger = initiate_logger(verbose=True, log_file_path='test.log')
    logger.debug(f"Running script with args: {repr(args)}")

    # Run the main function of the selected command
    args.func()
