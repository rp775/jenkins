import luigi
import requests
import pandas as pd
import json
from pandas.io.json import json_normalize
from collections import Counter
from luigi.contrib.external_program import ExternalProgramTask
import os
import csv 

class GroupsToJSON(luigi.Task):
   
    lat = luigi.Parameter()
    lon = luigi.Parameter()

    def run(self):

        uri = "https://run.mocky.io/v3/15dd8916-0427-4c82-934f-a8d1d105e4ec"
        df = pd.read_json(uri)
        print(df)
        df.to_json("groups.json")

    def output(self):
        return luigi.LocalTarget("groups.json")




class GroupsToCSV(luigi.contrib.external_program.ExternalProgramTask):
    file_path = "groups.csv"
    
    lat = luigi.Parameter()
    lon = luigi.Parameter()
    def run(self):
    	df_f = pd.read_json('groups.json')
    	df_f.SERA_RECORDS = pd.DataFrame(df_f.SERA_RECORDS.values.tolist())['OWNER']
    	df_f = df_f.groupby(['SYS_ID'])['SERA_RECORDS'].apply(','.join).reset_index()

    	for column_name, item in df_f.iteritems():
    		print(type(column_name))
    		print(column_name)
    		print('------\n')
    		print(type(item))
    		print(item)
    		print('------')
    	#df = pd.DataFrame(data,columns=['Name','Age'])



    def output(self):
        return luigi.LocalTarget(self.file_path)

    def requires(self):
        yield GroupsToJSON(self.lat, self.lon)





class Meetup(luigi.WrapperTask):
    def run(self):
        print("Running Meetup")

    def requires(self):
    	#PMAK-6031fcf9ab938a00422743a7-eec324e1c95a927c727124312b7cfa06cd
        #key = os.environ['MEETUP_API_KEY']
        lat = os.getenv('LAT', "51.5072")
        lon = os.getenv('LON', "0.1275")

        yield GroupsToCSV( lat, lon)


if __name__ == "__main__":
    luigi.run()
