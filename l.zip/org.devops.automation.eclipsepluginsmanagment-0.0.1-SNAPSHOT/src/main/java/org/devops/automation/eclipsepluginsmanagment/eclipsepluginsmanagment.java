/*
 Ecliplse Plugins Update site management by Raj Ponnusamy
 */
package org.devops.automation.eclipsepluginsmanagment;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.Writer;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.maven.model.Model;
import org.apache.maven.model.Plugin;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.apache.maven.model.io.xpp3.MavenXpp3Writer;
import org.apache.maven.shared.invoker.DefaultInvocationRequest;
import org.apache.maven.shared.invoker.DefaultInvoker;
import org.apache.maven.shared.invoker.InvocationRequest;
import org.apache.maven.shared.invoker.InvocationResult;
import org.apache.maven.shared.invoker.Invoker;
import org.codehaus.plexus.util.xml.Xpp3Dom;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.enums.CSVReaderNullFieldIndicator;

public class eclipsepluginsmanagment {

	static InputStream empty = new InputStream() {
		@Override
		public int read() {
			return -1; // end of stream
		}
	};

	public static String INPUTPLUGINSFILENAME = "approvedplugins.csv";

	private static Invoker invoker = null;
	public static String MAVEN_INSTALL_LOCATION = "/Users/sample/Downloads/plugins/apache-maven-3.6.3";
	public static Boolean MAVENDEBUG = true;
	public static String OUTPUTPLUGINSFILENAME = "target/approvedplugins.xml";
	public static String POMTEMPLATENAME = "template.xml";
	public static String RELEASEVERSION = "1.0";
	
	private static final List<String> PUBLISH_GOALS = Arrays.asList("clean", "package", "site-deploy");
	private static int recordcount = 1;

	public static String SITEDIRECTORY = "target";

	private static void genrateUpdateSitePOMFile(String[] pluginRecord) {
		Xpp3Dom xml = null;
		Xpp3Dom configuration;

		System.out.println("RecordNumber--" + recordcount + Arrays.toString(pluginRecord));
		System.out.println("id" + pluginRecord[0]);
		System.out.println("id" + pluginRecord.length);

		try {

			Model model = parsePomXmlFileToMavenPomModel(POMTEMPLATENAME);
			model.setArtifactId(pluginRecord[0]);
			model.setVersion(RELEASEVERSION);

			for (Plugin plugin : model.getBuild().getPlugins()) {

				if (plugin.getArtifactId().equals("tycho-p2-extras-plugin")) {

					configuration = (Xpp3Dom) plugin.getConfiguration();

					if (configuration instanceof Xpp3Dom) {

						xml = configuration;

						Xpp3Dom source = xml.getChild("source");
						Xpp3Dom ius = xml.getChild("ius");

						if (source == null) {
							source = new Xpp3Dom("source");
							xml.addChild(source);
						}

						if ((pluginRecord.length >= 1) && (pluginRecord.length <= 4))

						{

							Xpp3Dom repository = repository = new Xpp3Dom("repository");
							source.addChild(repository);

							if (pluginRecord.length >= 1) {
								System.out.println("id" + pluginRecord[0]);
								Xpp3Dom id = new Xpp3Dom("id");
								id.setValue(pluginRecord[0]);
								repository.addChild(id);
							}

							if (pluginRecord.length >= 2) {
								System.out.println("url" + pluginRecord[1]);
								Xpp3Dom url = new Xpp3Dom("url");
								url.setValue(pluginRecord[1]);
								repository.addChild(url);
							}

							if (pluginRecord.length >= 3) {
								System.out.println("layout" + pluginRecord[2]);
								Xpp3Dom layout = new Xpp3Dom("layout");
								layout.setValue(pluginRecord[2]);
								repository.addChild(layout);
							}

							if (pluginRecord.length == 4) {

								String[] iustoken = StringUtils.split(pluginRecord[3], "|");

								System.out.println(Arrays.toString(iustoken));

								if (ius == null) {
									ius = new Xpp3Dom("ius");
									xml.addChild(ius);
								}

								for (int i = 0; i < iustoken.length; i++) {

									String[] iuid = StringUtils.split(iustoken[i], ":");

									System.out.println(
											"RecordNumber:" + recordcount + "IUCount:" + i + Arrays.toString(iuid));

									Xpp3Dom iu = ius.getChild("iu");
									iu = new Xpp3Dom("iu");
									ius.addChild(iu);

									if (iuid.length <= 1) {
										Xpp3Dom id = iu.getChild("id");
										id = new Xpp3Dom("id");
										id.setValue(iuid[0]);
										iu.addChild(id);
									} else {

										Xpp3Dom id = iu.getChild("id");
										id = new Xpp3Dom("id");
										id.setValue(iuid[0]);
										iu.addChild(id);

										Xpp3Dom version = iu.getChild("version");
										version = new Xpp3Dom("version");
										version.setValue(iuid[1]);
										iu.addChild(version);

									}

								}

							}

						}

					}
					plugin.setConfiguration(xml);

				}

			}

			// write new pom
			parseMavenPomModelToXmlString(OUTPUTPLUGINSFILENAME, model);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @param args the command lineR arguments
	 *             https://jutzig.wordpress.com/2012/06/07/how-to-mirror-eclipse-p2-repositories/
	 */
	public static void main(String[] args) throws Exception {

		System.out.println("--------Input variable passed from pom file -------");
		Arrays.stream(args).forEach(System.out::println);
		
		INPUTPLUGINSFILENAME = args[0];
		OUTPUTPLUGINSFILENAME = args[1];
		POMTEMPLATENAME = args[2];
		MAVEN_INSTALL_LOCATION = args[3];
		SITEDIRECTORY = args[4];
		MAVENDEBUG = Boolean.parseBoolean(args[5]);
		RELEASEVERSION = args[6];
		
	

		// read initial pom

		FileReader reader = new FileReader(INPUTPLUGINSFILENAME);
		CSVReader csvReader = new CSVReaderBuilder(reader).withFieldAsNull(CSVReaderNullFieldIndicator.EMPTY_SEPARATORS)
				// Skip the header
				.withSkipLines(1).build();

		List<String[]> allData = csvReader.readAll();
		reader.close();
		csvReader.close();

		Iterator iter = allData.iterator();

		while (iter.hasNext())

		{

			genrateUpdateSitePOMFile((String[]) iter.next());

			eclipsepluginsmanagment instance = new eclipsepluginsmanagment();
			eclipsepluginsmanagment.publishSite(new File(SITEDIRECTORY), OUTPUTPLUGINSFILENAME);

		}

		recordcount++;

	}

	public static void parseMavenPomModelToXmlString(String path, Model model) throws Exception {
		MavenXpp3Writer mavenWriter = new MavenXpp3Writer();
		Writer writer = new FileWriter(path);
		mavenWriter.write(writer, model);
	}

	public static Model parsePomXmlFileToMavenPomModel(String path) throws Exception {

		Model model = null;
		FileReader reader = null;
		MavenXpp3Reader mavenreader = new MavenXpp3Reader();
		reader = new FileReader(path);
		model = mavenreader.read(reader);
		return model;

	}

	public static void publishSite(File siteDirectory, String POMfilename) throws Exception {
		InvocationRequest request = new DefaultInvocationRequest();

		request.setInputStream(empty);
		request.setDebug(MAVENDEBUG);

		request.setPomFile(new File(POMfilename));
		request.setGoals(PUBLISH_GOALS);
		invoker.setMavenHome(new File(MAVEN_INSTALL_LOCATION));
		InvocationResult result = invoker.execute(request);

		if (result.getExitCode() != 0) {
			if (result.getExecutionException() != null) {
				throw new Exception("Failed to publish site.", result.getExecutionException());
			} else {
				throw new Exception("Failed to publish site. Exit code: " + result.getExitCode());
			}
		}
	}

	@SuppressWarnings("static-access")
	public eclipsepluginsmanagment() {
		Invoker newInvoker = new DefaultInvoker();
		eclipsepluginsmanagment.invoker = newInvoker;
	}

}
